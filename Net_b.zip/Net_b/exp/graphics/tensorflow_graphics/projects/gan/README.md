# Code for training GANs

This project is currently being moved to tfg and contents of the folders are
subject to change.
