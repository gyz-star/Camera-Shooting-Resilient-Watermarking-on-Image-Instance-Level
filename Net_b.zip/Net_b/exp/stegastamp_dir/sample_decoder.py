#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 小何一定行

import glob
import torch
import model, dataset
from torchvision import transforms
from PIL import Image, ImageOps

from Net.args import options
from utils import get_secret_acc, get_warped_extracted_IMG
from model import MaskRCNN

device = torch.device('cuda:1')
checkpoint = torch.load('/opt/data/mingjin/pycharm/Exercise/stegastamp/StegaStamp-pytorch/result_model/result_model_StegaStamp.pth',
                        map_location=torch.device('cpu'))

encoder = model.StegaStampEncoder()
decoder = model.StegaStampDecoder(secret_size=100)
rCnnNet = MaskRCNN()
if torch.cuda.is_available():
    encoder = encoder.to(device)
    decoder = decoder.to(device)

encoder.load_state_dict(checkpoint['model_encoder'])
decoder.load_state_dict(checkpoint['model_decoder'])
rCnnNet.eval()
rCnnNet.to(device)


def main(img_path, dir_path=None):
    transform = transforms.Compose([
        transforms.Resize((400, 400), Image.BICUBIC),
        transforms.ToTensor(), ])

    files_list = []
    if img_path is not None:
        files_list = [img_path]
    elif dir_path is not None:
        files_list = glob.glob(dir_path + '/*')
    assert len(files_list) != 0, '图片路径错误~'
    secret = [1., 1., 1., 0., 0., 0., 1., 0., 0., 0., 0., 0., 1., 0., 1., 1., 0., 1.,
              0., 0., 1., 0., 1., 0., 0., 1., 0., 0., 1., 0., 1., 1., 1., 0., 0., 0.,
              0., 1., 0., 0., 1., 0., 1., 0., 0., 0., 0., 1., 1., 1., 0., 0., 1., 1.,
              1., 1., 1., 1., 1., 1., 1., 1., 0., 1., 1., 0., 1., 0., 1., 1., 1., 1.,
              1., 1., 1., 0., 0., 1., 1., 0., 1., 1., 1., 1., 0., 1., 0., 0., 1., 1.,
              1., 1., 0., 0., 1., 0., 0., 1., 1., 1.]
    secret = torch.tensor(secret).unsqueeze(0).float().to(device)  # 为了方便，选取了固定秘密消息
    acc_sum = 0
    count = 0
    for filename in files_list:
        img = transform(Image.open(filename).convert('RGB')).unsqueeze(0).to(device)
        dec = img
        # mask = rCnnNet(img)
        # if mask is None:
        #     continue
        # opt = options.getOpt()
        # dec = get_warped_extracted_IMG(img.clone(), mask.clone(), args=opt, isMul=False, isHomography=False, isResize=True)

        pred_sec = decoder(dec)

        acc = get_secret_acc(pred_sec, secret)
        count += 1
        acc_sum += acc
        print('acc:' + str(acc))
    print('count:%d\tacc:%.2f' % (count, acc_sum / count * 100))


if __name__ == '__main__':
    # dir_path = r'D:\BaiduNetdiskWorkspace\PycharmProject\Net\exp\sample\origin'
    dir_path = r'/opt/data/mingjin/pycharm/Net/image_folder/Wild/print/stegastamp/aligned'
    # dir_path = r'/opt/data/mingjin/pycharm/Net/image_folder/Wild/Stegastamp/encoded'
    # dir_path = None
    # img_path = r'D:\BaiduNetdiskWorkspace\PycharmProject\Net\exp\stegastamp_dir\1_screen.jpg'
    img_path = None
    main(img_path=img_path, dir_path=dir_path)
