#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 小何一定行

import glob
import os

import torch
import numpy as np
import torchvision
import lpips
import model, dataset
from torchvision import transforms
from PIL import Image, ImageOps
from kornia import color, losses

device = torch.device('cuda:1')
# checkpoint = torch.load('result_model_StegaStamp.pth', map_location=torch.device('cpu'))
checkpoint = torch.load('/opt/data/mingjin/pycharm/Exercise/stegastamp/StegaStamp-pytorch/result_model/result_model_StegaStamp.pth',
                        map_location=torch.device('cpu'))
# checkpoint = torch.load('/opt/data/mingjin/pycharm/Exercise/stegastamp/StegaStamp-pytorch/checkpoints/EXP_NAME=6/94000.pth',
#                         map_location=torch.device('cpu'))

encoder = model.StegaStampEncoder()
decoder = model.StegaStampDecoder(secret_size=100)
if torch.cuda.is_available():
    encoder = encoder.to(device)
    decoder = decoder.to(device)

encoder.load_state_dict(checkpoint['model_encoder'])
decoder.load_state_dict(checkpoint['model_decoder'])


def main(img_path, dir_path=None, save_path=None):
    transform = transforms.Compose([
        transforms.Resize((400, 400), Image.BICUBIC),
        transforms.ToTensor(), ])

    grid = []
    files_list = []
    if img_path is not None:
        files_list = [img_path]
    elif dir_path is not None:
        files_list = glob.glob(dir_path + '/*')
    assert len(files_list) != 0, '图片路径错误~'
    if save_path is not None:
        if not os.path.exists(save_path):
            os.makedirs(save_path)

    secret = [1., 1., 1., 0., 0., 0., 1., 0., 0., 0., 0., 0., 1., 0., 1., 1., 0., 1.,
              0., 0., 1., 0., 1., 0., 0., 1., 0., 0., 1., 0., 1., 1., 1., 0., 0., 0.,
              0., 1., 0., 0., 1., 0., 1., 0., 0., 0., 0., 1., 1., 1., 0., 0., 1., 1.,
              1., 1., 1., 1., 1., 1., 1., 1., 0., 1., 1., 0., 1., 0., 1., 1., 1., 1.,
              1., 1., 1., 0., 0., 1., 1., 0., 1., 1., 1., 1., 0., 1., 0., 0., 1., 1.,
              1., 1., 0., 0., 1., 0., 0., 1., 1., 1.]
    secret = torch.tensor(secret).unsqueeze(0).float().to(device)  # 为了方便，选取了固定秘密消息
    PSNR_SUM = 0
    LPIPS_SUM = 0
    SSIM_SUM = 0
    COUNT = 0
    for filename in files_list:
        # secret = np.random.binomial(1, 0.5, 100)
        # secret = torch.from_numpy(secret).float()
        img_cover = transform(Image.open(filename).convert('RGB')).unsqueeze(0).to(device)
        secret, img_cover = secret.to(device), img_cover.to(device)
        inputs = (secret, img_cover)

        residual = encoder(inputs)
        result_img = torch.clamp(img_cover + residual, 0, 1)
        # print('PSNR:' + str(losses.psnr(result_img, img_cover, 1.).item()))  # 计算psnr
        # print('SSIM:' + str(torch.mean(losses.ssim(result_img, img_cover, 11)).item()))  # 计算ssim

        PSNR = losses.psnr(result_img, img_cover, 1.).item()
        SSIM = torch.mean(losses.ssim(result_img, img_cover, 11)).item()
        loss_fn_alex = lpips.LPIPS(net='alex', verbose=False)
        loss_fn_alex = loss_fn_alex.to(device)
        LPIPS = torch.mean(loss_fn_alex(result_img, img_cover)).item()
        LPIPS_SUM += LPIPS
        PSNR_SUM += PSNR
        SSIM_SUM += SSIM
        COUNT += 1

        print('Count:%s\tPSNR = %.4f\tLPIPS = %.4f\tSSIM = %.4f\t' % (COUNT, PSNR, LPIPS, SSIM,))

        name = filename.split('\\')[-1] if filename.find('/') == -1 else filename.split('/')[-1]
        save_name = name.split('.')[0]
        slash = '\\' if filename.find('/') == -1 else '/'
        path_img_save = save_path + slash + save_name + '.jpg'
        torchvision.utils.save_image(result_img, fp=path_img_save, nrow=1, padding=0)
        # path_residual_save = save_path + '\\' + name + '_residual' + '.png'
        # torchvision.utils.save_image(residual + 0.5, fp=path_residual_save, nrow=1, padding=0)
    print('img_nums:%s\tPSNR = %.4f\tLPIPS = %.4f\tSSIM = %.4f\t' % (COUNT, PSNR_SUM / COUNT, LPIPS_SUM / COUNT, SSIM_SUM / COUNT,))


if __name__ == '__main__':
    # dir_path = r'D:\BaiduNetdiskWorkspace\PycharmProject\Net\exp\sample\origin'
    # dir_path = None
    # img_path = '1.jpg'
    # save_path = r'D:\BaiduNetdiskWorkspace\PycharmProject\Net\exp\stegastamp_dir'
    img_path = None
    # dir_path = '/opt/data/mingjin/pycharm/Data/HiDDeN/val'
    # save_path = '/opt/data/mingjin/pycharm/Net/exp/stegastamp_dir'
    dir_path = '/opt/data/mingjin/pycharm/Net/image_folder/Wild/origin'
    save_path = '/opt/data/mingjin/pycharm/Net/image_folder/Wild/Stegastamp/encoded'

    # dir_path = '/opt/data/mingjin/pycharm/Net/exp/sample/visual quality/origion'
    # save_path = '/opt/data/mingjin/pycharm/Net/exp/sample/visual quality/StegaStamp'
    # save_path = '/opt/data/mingjin/pycharm/Net/exp/sample/visual quality/rihoop'

    main(img_path=img_path, dir_path=dir_path, save_path=save_path)
