#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 小何一定行

import glob
import os
import random
import time

import cv2
import lpips
import torch
import numpy as np
import torchgeometry
import torchvision
from matplotlib import pyplot as plt
import sys

from model import MaskRCNN

sys.path.append("..")
sys.path.append("../../")
import model, dataset
from torchvision import transforms
from PIL import Image, ImageOps
from kornia import color, losses
from utils import get_secret_acc, Gauss_noise, tensor2im, im2tensor, get_rand_homography_mat, Random_noise, tensor2im, im2tensor
import kornia as K
from noise_layers.blur import BLUR
from noise_layers.color import Color_Manipulation
# from noise_layers_exp.jpeg import JPEGCompress
# from noise_layers_exp.resizeThenBack import RESIZE
from noise_layers_exp.crop import Crop
import warnings
from align_images import alignImage

warnings.filterwarnings("ignore")
device = torch.device('cuda:1')
# checkpoint = torch.load('result_model_StegaStamp.pth', map_location=torch.device('cpu'))
checkpoint = torch.load('/opt/data/mingjin/pycharm/Exercise/stegastamp/StegaStamp-pytorch/result_model/result_model_StegaStamp.pth',
                        map_location=torch.device('cpu'))
# checkpoint = torch.load('/opt/data/mingjin/pycharm/Exercise/stegastamp/StegaStamp-pytorch/checkpoints/EXP_NAME=6/94000.pth',
#                         map_location=torch.device('cpu'))
encoder = model.StegaStampEncoder()
decoder = model.StegaStampDecoder(secret_size=100)
if torch.cuda.is_available():
    encoder = encoder.to(device)
    decoder = decoder.to(device)

encoder.load_state_dict(checkpoint['model_encoder'])
decoder.load_state_dict(checkpoint['model_decoder'])
rCnnNet = MaskRCNN()
rCnnNet.eval()
rCnnNet.to(device)


def main(img_path, dir_path=None, save_path=None):
    transform = transforms.Compose([
        transforms.Resize((400, 400), Image.BICUBIC),
        transforms.ToTensor(), ])

    files_list = []
    if img_path is not None:
        files_list = [img_path]
    elif dir_path is not None:
        files_list = glob.glob(dir_path + '/*')
    assert len(files_list) != 0, '图片路径错误~'
    if save_path is not None:
        if not os.path.exists(save_path):
            os.makedirs(save_path)

    secret = [1., 1., 1., 0., 0., 0., 1., 0., 0., 0., 0., 0., 1., 0., 1., 1., 0., 1.,
              0., 0., 1., 0., 1., 0., 0., 1., 0., 0., 1., 0., 1., 1., 1., 0., 0., 0.,
              0., 1., 0., 0., 1., 0., 1., 0., 0., 0., 0., 1., 1., 1., 0., 0., 1., 1.,
              1., 1., 1., 1., 1., 1., 1., 1., 0., 1., 1., 0., 1., 0., 1., 1., 1., 1.,
              1., 1., 1., 0., 0., 1., 1., 0., 1., 1., 1., 1., 0., 1., 0., 0., 1., 1.,
              1., 1., 0., 0., 1., 0., 0., 1., 1., 1.]
    secret = torch.tensor(secret).unsqueeze(0).float().to(device)  # 为了方便，选取了固定秘密消息
    PSNR_SUM = 0
    LPIPS_SUM = 0
    SSIM_SUM = 0
    bit_SUM = 0
    COUNT = 0
    TIME_SUM = 0
    for filename in files_list:
        # secret = np.random.binomial(1, 0.5, 100)
        # secret = torch.from_numpy(secret).float()
        img_cover = transform(Image.open(filename).convert('RGB')).unsqueeze(0).to(device)
        secret, img_cover = secret.to(device), img_cover.to(device)
        inputs = (secret, img_cover)

        residual = encoder(inputs)
        result_img = torch.clamp(img_cover + residual, 0, 1)

        noised_img = result_img
        #################################################################################
        # mask = rCnnNet(noised_img)
        # if mask is None:
        #     continue
        # noised_img = noised_img * mask

        # # 选择加入模拟噪声,不需要的噪声注释掉即可 #
        # key = generate_random_key(10)
        # noised_img = noise.noise_layer(noised_img, key=key)
        # 透视扭曲校正后发生的像素重采样
        # h, w = noised_img.shape[2:4]
        # warp_scale = 0.1
        # homography = get_rand_homography_mat(noised_img, warp_scale)
        # homography = torch.from_numpy(homography).float().to(device)
        # noised_img = torchgeometry.warp_perspective(noised_img, homography[:, 1, :, :], dsize=(h, w))
        # noised_img = torchgeometry.warp_perspective(noised_img, homography[:, 0, :, :], dsize=(h, w))
        # 模糊
        # K_size = 5
        # blur = BLUR(N_blur=K_size)
        # noised_img = blur(noised_img)
        # - 模糊 - #
        # k_size_gauss = 5
        # noised_img = K.filters.gaussian_blur2d(noised_img, (k_size_gauss, k_size_gauss), (0.1, 1.0))
        # k_size_motion = 5
        # angle = torch.Tensor(noised_img.size()[0]).uniform_(-35, 35)
        # direction = torch.from_numpy(np.random.choice([1, 0, -1], noised_img.size()[0])).float()
        # noised_img = K.filters.motion_blur(noised_img, k_size_motion, angle, direction)

        # 放缩
        # resize = RESIZE()
        # resize_scale = torch.Tensor(1).uniform_(0.5, 2).item()
        # noised_img = resize(noised_img, resize_scale)

        crop = Crop(0.3)
        noised_img = crop(noised_img)
        #
        # # 颜色变换
        # contrast = [-0.2, 0.2]
        # color = [-0.06, 0.06]
        # brightness = [-0.2, 0.2]
        # con_scale = torch.tensor(1.0).uniform_(contrast[0], contrast[1]).item()
        # col_scale = torch.tensor(1.0).uniform_(color[0], color[1]).item()
        # bri_scale = torch.tensor(1.0).uniform_(brightness[0], brightness[1]).item()
        # noised_img = (1 + con_scale) * (noised_img + col_scale) + bri_scale
        # noised_img = torch.clip(noised_img, 0.0, 1.0)

        # random_noise_scale = torch.Tensor(1).uniform_(-0.1, 0.1).item()
        # gauss_noise_scale = torch.Tensor(1).uniform_(0., 0.02).item()
        #
        # noised_img = Random_noise(noised_img, random_noise_scale)
        # noised_img = Gauss_noise(noised_img, gauss_noise_scale)
        # noised_img = torch.clip(noised_img, 0.0, 1.0)

        # rnd_bri = 0.3
        # rnd_hue = 0.1
        # contrast_low = 0.5
        # contrast_high = 1.5
        # rnd_sat = 1.0
        # wait_dec = Color_Manipulation(wait_dec, rnd_bri, rnd_hue, contrast_low, contrast_high, rnd_sat)
        # # jpeg压缩
        # jpeg_quality = int(100. - torch.rand(1)[0] * 50)
        # # jpeg_quality = 70
        # noised_img = JPEGCompress(noised_img, jpeg_quality, device)

        start_time = time.time()
        # imReg, H = alignImage(tensor2im(noised_img), tensor2im(result_img))
        # noised_img = im2tensor(imReg).to(device)
        elapsed_time = time.time() - start_time
        TIME_SUM += elapsed_time
        #################################################################################

        PSNR = losses.psnr(result_img, img_cover, 1.).item()
        SSIM = torch.mean(losses.ssim(result_img, img_cover, 11)).item()
        loss_fn_alex = lpips.LPIPS(net='alex', verbose=False)
        loss_fn_alex = loss_fn_alex.to(device)
        LPIPS = torch.mean(loss_fn_alex(result_img, img_cover)).item()

        wait_dec = noised_img
        pred_sec = decoder(wait_dec)
        bit_acc = get_secret_acc(pred_sec, secret)
        bit_SUM += bit_acc
        LPIPS_SUM += LPIPS
        PSNR_SUM += PSNR
        SSIM_SUM += SSIM
        COUNT += 1
        print('Count:%s\tPSNR = %.4f\tLPIPS = %.4f\tSSIM = %.4f\tbit_acc =  %.5f\t' % (COUNT, PSNR, LPIPS, SSIM, bit_acc))

        if dir_path is None:
            # 展示相关图片
            cover = tensor2im(img_cover)  # 载体图像
            res = tensor2im(residual + 0.5)  # 残差
            result = tensor2im(result_img)  # 含水印图像
            dec = tensor2im(wait_dec)  # 加噪图像
            plt.figure(1)
            plt.subplot(2, 2, 1)
            plt.axis('off')
            plt.imshow(cover)
            plt.subplot(2, 2, 2)
            plt.axis('off')
            plt.imshow(res)
            plt.subplot(2, 2, 3)
            plt.axis('off')
            plt.imshow(result)
            plt.subplot(2, 2, 4)
            plt.axis('off')
            plt.imshow(dec)
            plt.show()

    print('img_nums:%s\tPSNR = %.3f\tLPIPS = %.3f\tSSIM = %.3f\tbit_acc =  %.5f\t' % (
        COUNT, PSNR_SUM / COUNT, LPIPS_SUM / COUNT, SSIM_SUM / COUNT, bit_SUM / COUNT))
    print('time:%f' % (TIME_SUM / COUNT))


if __name__ == '__main__':
    # dir_path = r'D:\BaiduNetdiskWorkspace\PycharmProject\Net\exp\sample\origin'
    dir_path = '/home/yizhi/Data/HiDDeN/test'
    # dir_path = '/opt/data/mingjin/pycharm/Data/HiDDeN/val'
    # img_path = r'D:\BaiduNetdiskWorkspace\PycharmProject\Net\exp\sample\origin\1.jpg'
    img_path = None
    main(img_path=img_path, dir_path=dir_path)
