import bchlib
import glob
from PIL import Image, ImageOps
import numpy as np
import tensorflow as tf
import tensorflow.compat.v1 as tf
# import tensorflow.contrib.image
from tensorflow.python.saved_model import tag_constants
from tensorflow.python.saved_model import signature_constants
import torch
import os

from Net.args import options
from models import MaskRCNN
from Net.utils import get_secret_acc, get_warped_extracted_IMG

os.environ["CUDA_VISIBLE_DEVICES"] = "1"

BCH_POLYNOMIAL = 137
BCH_BITS = 5


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str, default='/opt/data/mingjin/pycharm/Net/exp/rihoop_dir/saved_models/demo1')
    parser.add_argument('--image', type=str, default=None)
    parser.add_argument('--images_dir', type=str,
                        default='/opt/data/mingjin/pycharm/Net/image_folder/Wild/print/RIHOOP/aligned')
    parser.add_argument('--secret_size', type=int, default=100)
    args = parser.parse_args()

    if args.image is not None:
        files_list = [args.image]
    elif args.images_dir is not None:
        files_list = glob.glob(args.images_dir + '/*')
    else:
        print('Missing input image')
        return

    sess = tf.InteractiveSession(graph=tf.Graph())

    model = tf.saved_model.loader.load(sess, [tag_constants.SERVING], args.model)
    rCnnNet = MaskRCNN()
    rCnnNet.eval()
    input_image_name = model.signature_def[signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY].inputs['image'].name
    input_image = tf.get_default_graph().get_tensor_by_name(input_image_name)

    output_secret_name = model.signature_def[signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY].outputs['decoded'].name
    output_secret = tf.get_default_graph().get_tensor_by_name(output_secret_name)

    bch = bchlib.BCH(BCH_POLYNOMIAL, BCH_BITS)

    secret = [1., 1., 1., 0., 0., 0., 1., 0., 0., 0., 0., 0., 1., 0., 1., 1., 0., 1.,
              0., 0., 1., 0., 1., 0., 0., 1., 0., 0., 1., 0., 1., 1., 1., 0., 0., 0.,
              0., 1., 0., 0., 1., 0., 1., 0., 0., 0., 0., 1., 1., 1., 0., 0., 1., 1.,
              1., 1., 1., 1., 1., 1., 1., 1., 0., 1., 1., 0., 1., 0., 1., 1., 1., 1.,
              1., 1., 1., 0., 0., 1., 1., 0., 1., 1., 1., 1., 0., 1., 0., 0., 1., 1.,
              1., 1., 0., 0., 1., 0., 0., 1., 1., 1.]
    acc_sum = 0
    count = 0
    for filename in files_list:
        image = Image.open(filename).convert("RGB")
        image = np.array(ImageOps.fit(image, (400, 400)), dtype=np.float32)
        image /= 255.

        # feed_dict = {input_image: [image]}
        # secret = sess.run([output_secret], feed_dict=feed_dict)[0][0]

        # packet_binary = "".join([str(int(bit)) for bit in secret[:96]])
        # packet = bytes(int(packet_binary[i: i + 8], 2) for i in range(0, len(packet_binary), 8))
        # packet = bytearray(packet)
        #
        # data, ecc = packet[:-bch.ecc_bytes], packet[-bch.ecc_bytes:]
        # bitflips = bch.decode_inplace(data, ecc)

        # if bitflips != -1:
        #     try:
        #         code = data.decode("utf-8")
        #         print(filename, code)
        #         continue
        #     except:
        #         continue
        # print(filename, 'Failed to decode')

        image = torch.from_numpy(np.array(image)).unsqueeze(0).permute(0, 3, 1, 2)
        mask = rCnnNet(image)
        if mask is None:
            continue
        opt = options.getOpt()
        image = get_warped_extracted_IMG(image.clone(), mask.clone(), args=opt, isMul=False, isHomography=False, isResize=True)
        image = image.permute(0, 2, 3, 1).squeeze().detach().numpy()

        out_feed_dict = {input_image: [image]}
        dec_secret = sess.run([output_secret], feed_dict=out_feed_dict)[0][0]

        gt_sec = torch.tensor(secret).unsqueeze(0).float()
        dec_sec = torch.tensor(dec_secret).unsqueeze(0).float()
        acc = get_secret_acc(dec_sec, gt_sec)
        acc_sum += acc
        count += 1
        print('acc:' + str(acc))
    print('count:%d\tacc:%.2f' % (count, acc_sum / count * 100))


if __name__ == "__main__":
    main()
