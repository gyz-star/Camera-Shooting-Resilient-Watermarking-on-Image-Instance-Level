import time

import bchlib
import sys

import torchgeometry

sys.path.append("..")
sys.path.append("../../")
import glob
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
from PIL import Image, ImageOps
import numpy as np
# import tensorflow as tf
import tensorflow.compat.v1 as tf
from tensorflow.python.saved_model import tag_constants
from tensorflow.python.saved_model import signature_constants
from kornia import color, losses
from utils import get_secret_acc, Random_noise, Gauss_noise, get_rand_homography_mat, tensor2im, im2tensor
import torch
import lpips_tf
from lpips_pytorch.lpips import LPIPS
from models import MaskRCNN
from noise_layers_exp.resizeThenBack import RESIZE
import kornia as K
from noise_layers_exp.jpeg import JPEGCompress
from noise_layers_exp.crop import Crop
from align_images import alignImage

compute_lpips = LPIPS()
rCnnNet = MaskRCNN()


def main(cp_path, img_path=None, dir_path=None, save_path=None):
    if img_path is not None:
        files_list = [img_path]
    elif dir_path is not None:
        files_list = glob.glob(dir_path + '/*')
    else:
        print('Missing input image')
        return

    sess = tf.InteractiveSession(graph=tf.Graph())

    model = tf.saved_model.loader.load(sess, [tag_constants.SERVING], cp_path)
    rCnnNet.eval()
    # rCnnNet.to(device)

    input_secret_name = model.signature_def[signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY].inputs['secret'].name
    input_image_name = model.signature_def[signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY].inputs['image'].name
    output_secret_name = model.signature_def[signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY].outputs['decoded'].name
    input_secret = tf.get_default_graph().get_tensor_by_name(input_secret_name)
    input_image = tf.get_default_graph().get_tensor_by_name(input_image_name)
    output_secret = tf.get_default_graph().get_tensor_by_name(output_secret_name)

    output_stegastamp_name = model.signature_def[signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY].outputs[
        'stegastamp'].name
    output_residual_name = model.signature_def[signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY].outputs[
        'residual'].name
    output_stegastamp = tf.get_default_graph().get_tensor_by_name(output_stegastamp_name)
    output_residual = tf.get_default_graph().get_tensor_by_name(output_residual_name)

    width = 400
    height = 400

    secret = [1., 1., 1., 0., 0., 0., 1., 0., 0., 0., 0., 0., 1., 0., 1., 1., 0., 1.,
              0., 0., 1., 0., 1., 0., 0., 1., 0., 0., 1., 0., 1., 1., 1., 0., 0., 0.,
              0., 1., 0., 0., 1., 0., 1., 0., 0., 0., 0., 1., 1., 1., 0., 0., 1., 1.,
              1., 1., 1., 1., 1., 1., 1., 1., 0., 1., 1., 0., 1., 0., 1., 1., 1., 1.,
              1., 1., 1., 0., 0., 1., 1., 0., 1., 1., 1., 1., 0., 1., 0., 0., 1., 1.,
              1., 1., 0., 0., 1., 0., 0., 1., 1., 1.]

    if save_path is not None:
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        size = (width, height)

        PSNR_SUM = 0
        LPIPS_SUM = 0
        SSIM_SUM = 0
        bit_SUM = 0
        COUNT = 0
        TIME_SUM = 0
        for filename in files_list:
            if COUNT >= 50:
                break
            image = Image.open(filename).convert("RGB")
            image = np.array(ImageOps.fit(image, size), dtype=np.float32)
            image /= 255.

            feed_dict = {input_secret: [secret],
                         input_image: [image]}

            hidden_img, residual = sess.run([output_stegastamp, output_residual], feed_dict=feed_dict)
            encoded_img = torch.from_numpy(np.array(hidden_img)).permute(0, 3, 1, 2)
            origin_img = torch.from_numpy(np.array(image)).unsqueeze(0).permute(0, 3, 1, 2)
            noised_img = encoded_img

            # mask = rCnnNet(noised_img)
            # if mask is None:
            #     continue
            # noised_img = noised_img * mask
            #
            resize = RESIZE()
            resize_scale = torch.Tensor(1).uniform_(0.5, 2).item()
            noised_img = resize(noised_img, resize_scale)

            crop = Crop(0.3)
            noised_img = crop(noised_img)

            k_size_gauss = 7
            noised_img = K.filters.gaussian_blur2d(noised_img, (k_size_gauss, k_size_gauss), (0.1, 1.0))

            k_size_motion = 7
            angle = torch.Tensor(noised_img.size()[0]).uniform_(-35, 35)
            direction = torch.from_numpy(np.random.choice([1, 0, -1], noised_img.size()[0])).float()
            noised_img = K.filters.motion_blur(noised_img, k_size_motion, angle, direction)

            contrast = [-0.3, 0.3]
            color = [-0.1, 0.1]
            brightness = [-0.3, 0.3]
            con_scale = torch.tensor(1.0).uniform_(contrast[0], contrast[1]).item()
            col_scale = torch.tensor(1.0).uniform_(color[0], color[1]).item()
            bri_scale = torch.tensor(1.0).uniform_(brightness[0], brightness[1]).item()
            noised_img = (1 + con_scale) * (noised_img + col_scale) + bri_scale
            noised_img = torch.clip(noised_img, 0.0, 1.0)

            random_noise_scale = torch.Tensor(1).uniform_(-0.1, 0.1).item()
            gauss_noise_scale = torch.Tensor(1).uniform_(0., 0.02).item()

            noised_img = Random_noise(noised_img, random_noise_scale)
            noised_img = Gauss_noise(noised_img, gauss_noise_scale)
            noised_img = torch.clip(noised_img, 0.0, 1.0)

            # jpeg_quality = int(100. - torch.rand(1)[0] * 50)
            jpeg_quality = 50
            noised_img = JPEGCompress(noised_img, jpeg_quality, 'cpu')

            h, w = noised_img.shape[2:4]
            warp_scale = 0.2
            homography = get_rand_homography_mat(noised_img, warp_scale)
            homography = torch.from_numpy(homography).float()
            noised_img = torchgeometry.warp_perspective(noised_img, homography[:, 1, :, :], dsize=(h, w))

            start_time = time.time()
            # imReg, H = alignImage(tensor2im(noised_img), tensor2im(encoded_img))
            # noised_img = im2tensor(imReg)
            elapsed_time = time.time() - start_time
            TIME_SUM += elapsed_time

            wait_dec = noised_img.permute(0, 2, 3, 1).detach().numpy()
            out_feed_dict = {input_image: wait_dec}
            dec_secret = sess.run([output_secret], feed_dict=out_feed_dict)[0][0]

            LPIPS = compute_lpips(encoded_img, origin_img)

            PSNR = losses.psnr(encoded_img, origin_img, 1.).item()
            SSIM = torch.mean(losses.ssim(encoded_img, origin_img, 11)).item()
            gt_sec = torch.tensor(secret).unsqueeze(0).float()
            dec_sec = torch.tensor(dec_secret).unsqueeze(0).float()
            bit_acc = get_secret_acc(dec_sec, gt_sec)
            bit_SUM += bit_acc
            LPIPS_SUM += LPIPS
            PSNR_SUM += PSNR
            SSIM_SUM += SSIM
            COUNT += 1

            print('Count:%s\tPSNR = %.4f\tLPIPS = %.4f\tSSIM = %.4f\tbit_acc =  %.5f\t' % (COUNT, PSNR, LPIPS, SSIM, bit_acc))

            save_name = filename.split('/')[-1].split('.')[0]
            rescaled = (hidden_img[0] * 255).astype(np.uint8)
            # raw_img = (image * 255).astype(np.uint8)
            # residual = residual[0] + .5
            # residual = (residual * 255).astype(np.uint8)
            # im = Image.fromarray(np.array(rescaled))
            # im.save(save_path + '/' + save_name + '_result.jpg')
            # im = Image.fromarray(np.squeeze(np.array(residual)))
            # im.save(save_path + '/' + save_name + '_residual.png')

        print('img_nums:%s\tPSNR = %.3f\tLPIPS = %.3f\tSSIM = %.3f\tbit_acc =  %.5f\t' % (
            COUNT, PSNR_SUM / COUNT, LPIPS_SUM / COUNT, SSIM_SUM / COUNT, bit_SUM / COUNT))
        print(TIME_SUM / COUNT)


if __name__ == "__main__":
    cp_path = '/opt/data/mingjin/pycharm/Net/exp/rihoop_dir/saved_models/demo1'
    # img_path = '/opt/data/mingjin/pycharm/Net/exp/sample/origin/1.jpg'
    img_path = None
    # dir_path = None
    dir_path = '/opt/data/mingjin/pycharm/Data/HiDDeN/test'
    # dir_path = '/opt/data/mingjin/pycharm/Net/image_folder/Wild/origin'
    # dir_path = '/opt/data/mingjin/pycharm/Data/mirflickr25k/mirflickr'
    save_path = '/opt/data/mingjin/pycharm/Net/image_folder/Wild/RIHOOP/encoded'
    main(cp_path, img_path, dir_path, save_path)
