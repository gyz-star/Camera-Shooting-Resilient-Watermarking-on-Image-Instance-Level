import cv2
import itertools
import numpy as np
import random
import tensorflow as tf
# import tensorflow.compat.v1 as tf
from tensorflow_graphics.geometry.transformation import quaternion
from tensorflow_graphics.rendering.reflectance import lambertian
from tensorflow_graphics.rendering.reflectance import phong
from tensorflow_graphics.rendering.camera import perspective
from tensorflow_graphics.geometry.representation import grid
from tensorflow_graphics.geometry.representation import ray
from tensorflow_graphics.geometry.representation import vector
import random
import math as m
import string

import cv2
import numpy as np
import random
import torch
import torchgeometry
from torch.nn import init
from torch import autograd, nn
import torch.nn.functional as F
import kornia as K
from torchvision import transforms


def light_simulation(img_orig, light_intensity_term, light_albedo):
    # img_orig.shape=[4,400,400,3],depth通道
    height, width, depth = img_orig.shape.as_list()[1: 4]
    print('image shape:', height, width, depth)
    # light_x_position = random.uniform(-0.4, 0.4)
    # light_y_position = random.uniform(-0.4, 0.4)
    # albedo_red = random.uniform(0.5, 0.7)
    # albedo_green = random.uniform(0.5, 1.0)
    # albedo_blue = random.uniform(0.5, 1.0)
    # albedo_red = 0.7
    # albedo_green = 1.0
    # albedo_blue = 1.0

    # albedo_array = np.array((0.8, 0.9, 1.0))
    # albedo_array_red = np.array((0.5, 0.6, 0.7))
    # albedo_red = albedo_array_red[random.randint(0, 2)]
    # albedo_green = albedo_array[random.randint(0, 2)]
    # albedo_blue = albedo_array[random.randint(0, 2)]

    light_red = 1
    light_green = 1
    light_blue = 1
    # 镜面反射率
    specular_percentage = 0.5  # specular albedo rate
    # 反射
    shininess = 4
    # 漫反射
    diffuse_percentage = 1.0 - specular_percentage  # diffuse albedo rate
    dtype = np.float32
    # albedo rate combination
    # albedo = np.array((albedo_red, albedo_green, albedo_blue), dtype=dtype)
    # 反照率组合，3个数
    albedo = light_albedo
    # image points and image normal
    # 图像点与图像法向shape[400,400,3]
    image_points = np.zeros((height, width, depth), dtype=dtype)
    image_normal = np.zeros((height, width, depth), dtype=dtype)
    # 距离
    distance = 300.0
    for i in range(0, height):
        for j in range(0, width):
            # 图像点（i，j）三个通道的值分别为i,j,distance
            image_points[i][j] = (i, j, distance)
            # 图像法向量为(0.0, 0.0, -1.0)
            image_normal[i][j] = (0.0, 0.0, -1.0)
    print('begin ', image_points)
    image_points = tf.convert_to_tensor(image_points, dtype=dtype)
    image_normal = tf.convert_to_tensor(image_normal, dtype=dtype)
    # 沿着通道l2正则化，【400,400,3】
    image_normal = tf.math.l2_normalize(image_normal, axis=-1)
    print('before ', image_points)
    # 使用0代替数组x中的nan元素
    '''自己改动'''
    # 原代码
    # image_points = np.nan_to_num(image_points)

    image_points = tf.Session().run(image_points)
    image_points = np.nan_to_num(image_points)
    image_points = tf.convert_to_tensor(image_points, dtype=dtype)
    print('after ', image_points)
    # 原代码
    # image_normal = np.nan_to_num(image_normal)
    image_normal = tf.Session().run(image_normal)
    image_normal = np.nan_to_num(image_normal)
    image_points = tf.convert_to_tensor(image_points, dtype=dtype)
    # 光源位置正中央
    light_position = np.array((height / 2.0, width / 2.0, 0.0), dtype=dtype)  # [200,200,0]
    # 表面中心
    surface_center = np.array((height / 2.0, width / 2.0, distance), dtype=dtype)  # [200,200,300]
    # 入射向量
    vector_light_to_surface_center = light_position - surface_center  # [0,0,-300]
    # 入射光线方向
    incoming_light_direction = tf.math.l2_normalize(image_points - light_position, axis=-1)
    # outgoing ray
    outgoing_ray = np.array((0.0, 0.0, -1.0), dtype=dtype)
    albedo = tf.broadcast_to(albedo, tf.shape(image_normal))
    # light intensity,vector.dot=vector_light_to_surface_center*vector_light_to_surface_center
    # 然后按照axis维度求和
    light_intensity_scale = vector.dot(vector_light_to_surface_center, vector_light_to_surface_center,
                                       axis=-1) * 4.0 * m.pi
    light_intensity = np.array((light_red, light_green, light_blue)) * light_intensity_scale * light_intensity_term
    # Lambertian BRDF
    # incoming_light_direction shape=(400,400,3), outgoing_ray: [0, 0, -1], image_normal shape=(400,400,3), albedo shape=(400,400,3)
    brdf_lambertian = diffuse_percentage * lambertian.brdf(incoming_light_direction, outgoing_ray, image_normal, albedo)
    # Phong BRDF
    brdf_phong = specular_percentage * phong.brdf(incoming_light_direction, outgoing_ray, image_normal,
                                                  np.array((shininess,), dtype=dtype), albedo)
    # Composite BRDF
    brdf_composite = brdf_lambertian + brdf_phong
    # compute irradiance
    cosine_term = vector.dot(image_normal, -incoming_light_direction)
    cosine_term = tf.math.maximum(tf.zeros_like(cosine_term), cosine_term)
    vector_light_to_surface = image_points - light_position
    light_to_surface_distance_squared = vector.dot(vector_light_to_surface, vector_light_to_surface, axis=-1)
    irradiance = light_intensity / (4 * m.pi * light_to_surface_distance_squared) * cosine_term
    # Rendering equation
    radiance = brdf_composite * irradiance
    radiance_lambertian = brdf_lambertian * irradiance
    radiance_phong = brdf_phong * irradiance
    # Saturates radiances at 1 for rendering purposes.
    # print('radiance:', radiance)
    radiance = tf.minimum(radiance, 1.0)
    # Gammma correction
    radiance = tf.pow(radiance, 1.0 / 2.2)
    image_light = tf.add(img_orig, radiance)
    image_light = tf.minimum(image_light, 1.0)
    # image_light = img_orig + radiance
    return image_light


def motion_screen(img_orig, batch_size):
    img_orig = tf.convert_to_tensor(img_orig)
    img_orig = tf.cast(img_orig, tf.float32)
    height, width = img_orig.shape.as_list()[1:3]
    # print('motion_screen', height, width)
    offset_x, offset_y = np.random.randint(0, 10, size=2)

    tmp_r = img_orig[:, :, :, 0]
    tmp_g = tf.zeros((batch_size, height, width))
    tmp_b = tf.zeros((batch_size, height, width))
    channel_r = tf.stack([tmp_r, tmp_g, tmp_b], 3)
    channel_r = tf.manip.roll(channel_r, [offset_y, offset_x], axis=[1, 2])

    tmp_r = tf.zeros((batch_size, height, width))
    tmp_g = img_orig[:, :, :, 1]
    tmp_b = img_orig[:, :, :, 2]
    channel_gb = tf.stack([tmp_r, tmp_g, tmp_b], 3)

    canvas_r = tf.zeros((batch_size, height, width, 3), dtype=np.float32)
    mask = np.zeros((batch_size, height, width, 3))
    mask[:, offset_y:, offset_x:, :] = 1
    # print(mask)
    mask = tf.convert_to_tensor(mask)
    mask = tf.cast(mask, tf.float32)
    canvas_r = tf.multiply(channel_r, mask)

    result = tf.add(canvas_r, channel_gb)
    return result


def random_blur_kernel(probs, N_blur, sigrange_gauss, sigrange_line, wmin_line):
    N = N_blur
    coords = tf.to_float(tf.stack(tf.meshgrid(tf.range(N_blur), tf.range(N_blur), indexing='ij'), -1)) - (.5 * (N - 1))
    # coords = tf.to_float(coords)
    manhat = tf.reduce_sum(tf.abs(coords), -1)

    # nothing, default

    vals_nothing = tf.to_float(manhat < .5)

    # gauss

    sig_gauss = tf.random.uniform([], sigrange_gauss[0], sigrange_gauss[1])
    vals_gauss = tf.exp(-tf.reduce_sum(coords ** 2, -1) / 2. / sig_gauss ** 2)

    # line

    theta = tf.random_uniform([], 0, 2. * np.pi)
    v = tf.convert_to_tensor([tf.cos(theta), tf.sin(theta)])
    dists = tf.reduce_sum(coords * v, -1)

    sig_line = tf.random.uniform([], sigrange_line[0], sigrange_line[1])
    w_line = tf.random.uniform([], wmin_line, .5 * (N - 1) + .1)

    vals_line = tf.exp(-dists ** 2 / 2. / sig_line ** 2) * tf.to_float(manhat < w_line)

    t = tf.random_uniform([])
    vals = vals_nothing
    vals = tf.cond(t < probs[0] + probs[1], lambda: vals_line, lambda: vals)
    vals = tf.cond(t < probs[0], lambda: vals_gauss, lambda: vals)

    v = vals / tf.reduce_sum(vals)
    z = tf.zeros_like(v)
    f = tf.reshape(tf.stack([v, z, z, z, v, z, z, z, v], -1), [N, N, 3, 3])

    return f


def get_rand_transform_matrix(image_size, d, batch_size):
    Ms = np.zeros((batch_size, 2, 8))

    for i in range(batch_size):
        '''test 11-19'''
        '''
        tl_x = random.uniform(-d, d)     # Top left corner, top
        tl_y = random.uniform(-d, d)    # Top left corner, left
        bl_x = random.uniform(-d, d)  # Bot left corner, bot
        bl_y = random.uniform(-d, d)    # Bot left corner, left
        tr_x = random.uniform(-d, d)     # Top right corner, top
        tr_y = random.uniform(-d, d)   # Top right corner, right
        br_x = random.uniform(-d, d)  # Bot right corner, bot
        br_y = random.uniform(-d, d)   # Bot right corner, right
        '''
        '''test 11-19'''
        tl_x = random.uniform(0, d)  # Top left corner, top
        tl_y = random.uniform(0, d)  # Top left corner, left
        bl_x = random.uniform(0, d)  # Bot left corner, bot
        bl_y = random.uniform(0, d)  # Bot left corner, left
        tr_x = random.uniform(0, d)  # Top right corner, top
        tr_y = random.uniform(0, d)  # Top right corner, right
        br_x = random.uniform(0, d)  # Bot right corner, bot
        br_y = random.uniform(0, d)  # Bot right corner, right
        '''test 11-19'''
        '''
        rect = np.array([
            [tl_x, tl_y],
            [tr_x + image_size, tr_y],
            [br_x + image_size, br_y + image_size],
            [bl_x, bl_y +  image_size]], dtype = "float32")
        '''
        rect = np.array([
            [tl_x, tl_y],
            [image_size - tr_x, tr_y],
            [image_size - br_x, image_size - br_y],
            [bl_x, image_size - bl_y]], dtype="float32")
        # print(rect)
        dst = np.array([
            [0, 0],
            [image_size, 0],
            [image_size, image_size],
            [0, image_size]], dtype="float32")

        M = cv2.getPerspectiveTransform(rect, dst)
        M_inv = np.linalg.inv(M)
        Ms[i, 0, :] = M_inv.flatten()[:8]
        Ms[i, 1, :] = M.flatten()[:8]
    return Ms


def get_rnd_brightness_tf(rnd_bri, rnd_hue, batch_size):
    # 随机均匀分布，形状为(batch_size,1,1,3)
    rnd_hue = tf.random.uniform((batch_size, 1, 1, 3), -rnd_hue, rnd_hue)
    # 随机均匀分布，形状为(batch_size,1,1,1)
    rnd_brightness = tf.random.uniform((batch_size, 1, 1, 1), -rnd_bri, rnd_bri)
    # 返回形状为(batch_size,1,1,3)，相加
    return rnd_hue + rnd_brightness


## Differentiable JPEG, Source - https://github.com/rshin/differentiable-jpeg/blob/master/jpeg-tensorflow.ipynb

# 1. RGB -> YCbCr
# https://en.wikipedia.org/wiki/YCbCr
def rgb_to_ycbcr(image):
    matrix = np.array(
        [[65.481, 128.553, 24.966], [-37.797, -74.203, 112.],
         [112., -93.786, -18.214]],
        dtype=np.float32).T / 255
    shift = [16., 128., 128.]

    result = tf.tensordot(image, matrix, axes=1) + shift
    result.set_shape(image.shape.as_list())
    return result


def rgb_to_ycbcr_jpeg(image):
    matrix = np.array(
        [[0.299, 0.587, 0.114], [-0.168736, -0.331264, 0.5],
         [0.5, -0.418688, -0.081312]],
        dtype=np.float32).T
    shift = [0., 128., 128.]

    result = tf.tensordot(image, matrix, axes=1) + shift
    result.set_shape(image.shape.as_list())
    return result


# 2. Chroma subsampling
def downsampling_420(image):
    # input: batch x height x width x 3
    # output: tuple of length 3
    #   y:  batch x height x width
    #   cb: batch x height/2 x width/2
    #   cr: batch x height/2 x width/2
    y, cb, cr = tf.split(image, 3, axis=3)
    cb = tf.nn.avg_pool(
        cb, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')
    cr = tf.nn.avg_pool(
        cr, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')
    return (tf.squeeze(
        y, axis=-1), tf.squeeze(
        cb, axis=-1), tf.squeeze(
        cr, axis=-1))


# 3. Block splitting
# From https://stackoverflow.com/questions/41564321/split-image-tensor-into-small-patches
def image_to_patches(image):
    # input: batch x h x w
    # output: batch x h*w/64 x h x w
    k = 8
    height, width = image.shape.as_list()[1:3]
    batch_size = tf.shape(image)[0]
    image_reshaped = tf.reshape(image, [batch_size, height // k, k, -1, k])
    image_transposed = tf.transpose(image_reshaped, [0, 1, 3, 2, 4])
    return tf.reshape(image_transposed, [batch_size, -1, k, k])


# 4. DCT
def dct_8x8_ref(image):
    image = image - 128
    result = np.zeros((8, 8), dtype=np.float32)
    for u, v in itertools.product(range(8), range(8)):
        value = 0
        for x, y in itertools.product(range(8), range(8)):
            value += image[x, y] * np.cos((2 * x + 1) * u * np.pi / 16) * np.cos(
                (2 * y + 1) * v * np.pi / 16)
        result[u, v] = value
    alpha = np.array([1. / np.sqrt(2)] + [1] * 7)
    scale = np.outer(alpha, alpha) * 0.25
    return result * scale


def dct_8x8(image):
    image = image - 128
    tensor = np.zeros((8, 8, 8, 8), dtype=np.float32)
    for x, y, u, v in itertools.product(range(8), repeat=4):
        tensor[x, y, u, v] = np.cos((2 * x + 1) * u * np.pi / 16) * np.cos(
            (2 * y + 1) * v * np.pi / 16)
    alpha = np.array([1. / np.sqrt(2)] + [1] * 7)
    scale = np.outer(alpha, alpha) * 0.25
    result = scale * tf.tensordot(image, tensor, axes=2)
    result.set_shape(image.shape.as_list())
    return result


# 5. Quantizaztion
y_table = np.array(
    [[16, 11, 10, 16, 24, 40, 51, 61], [12, 12, 14, 19, 26, 58, 60,
                                        55], [14, 13, 16, 24, 40, 57, 69, 56],
     [14, 17, 22, 29, 51, 87, 80, 62], [18, 22, 37, 56, 68, 109, 103,
                                        77], [24, 35, 55, 64, 81, 104, 113, 92],
     [49, 64, 78, 87, 103, 121, 120, 101], [72, 92, 95, 98, 112, 100, 103, 99]],
    dtype=np.float32).T
c_table = np.empty((8, 8), dtype=np.float32)
c_table.fill(99)
c_table[:4, :4] = np.array([[17, 18, 24, 47], [18, 21, 26, 66],
                            [24, 26, 56, 99], [47, 66, 99, 99]]).T


def y_quantize(image, rounding, factor=1):
    image = image / (y_table * factor)
    image = rounding(image)
    return image


def c_quantize(image, rounding, factor=1):
    image = image / (c_table * factor)
    image = rounding(image)
    return image


# -5. Dequantization
def y_dequantize(image, factor=1):
    return image * (y_table * factor)


def c_dequantize(image, factor=1):
    return image * (c_table * factor)


# -4. Inverse DCT
def idct_8x8_ref(image):
    alpha = np.array([1. / np.sqrt(2)] + [1] * 7)
    alpha = np.outer(alpha, alpha)
    image = image * alpha

    result = np.zeros((8, 8), dtype=np.float32)
    for u, v in itertools.product(range(8), range(8)):
        value = 0
        for x, y in itertools.product(range(8), range(8)):
            value += image[x, y] * np.cos((2 * u + 1) * x * np.pi / 16) * np.cos(
                (2 * v + 1) * y * np.pi / 16)
        result[u, v] = value
    return result * 0.25 + 128


def idct_8x8(image):
    alpha = np.array([1. / np.sqrt(2)] + [1] * 7)
    alpha = np.outer(alpha, alpha)
    image = image * alpha

    tensor = np.zeros((8, 8, 8, 8), dtype=np.float32)
    for x, y, u, v in itertools.product(range(8), repeat=4):
        tensor[x, y, u, v] = np.cos((2 * u + 1) * x * np.pi / 16) * np.cos(
            (2 * v + 1) * y * np.pi / 16)
    result = 0.25 * tf.tensordot(image, tensor, axes=2) + 128
    result.set_shape(image.shape.as_list())
    return result


# -3. Block joining
def patches_to_image(patches, height, width):
    # input: batch x h*w/64 x h x w
    # output: batch x h x w
    k = 8
    batch_size = tf.shape(patches)[0]
    image_reshaped = tf.reshape(patches,
                                [batch_size, height // k, width // k, k, k])
    image_transposed = tf.transpose(image_reshaped, [0, 1, 3, 2, 4])
    return tf.reshape(image_transposed, [batch_size, height, width])


# -2. Chroma upsampling
def upsampling_420(y, cb, cr):
    # input:
    #   y:  batch x height x width
    #   cb: batch x height/2 x width/2
    #   cr: batch x height/2 x width/2
    # output:
    #   image: batch x height x width x 3
    def repeat(x, k=2):
        height, width = x.shape.as_list()[1:3]
        x = tf.expand_dims(x, -1)
        x = tf.tile(x, [1, 1, k, k])
        x = tf.reshape(x, [-1, height * k, width * k])
        return x

    cb = repeat(cb)
    cr = repeat(cr)
    return tf.stack((y, cb, cr), axis=-1)


# -1. YCbCr -> RGB
def ycbcr_to_rgb(image):
    matrix = np.array(
        [[298.082, 0, 408.583], [298.082, -100.291, -208.120],
         [298.082, 516.412, 0]],
        dtype=np.float32).T / 256
    shift = [-222.921, 135.576, -276.836]

    result = tf.tensordot(image, matrix, axes=1) + shift
    result.set_shape(image.shape.as_list())
    return result


def ycbcr_to_rgb_jpeg(image):
    matrix = np.array(
        [[1., 0., 1.402], [1, -0.344136, -0.714136], [1, 1.772, 0]],
        dtype=np.float32).T
    shift = [0, -128, -128]

    result = tf.tensordot(image + shift, matrix, axes=1)
    result.set_shape(image.shape.as_list())
    return result


def diff_round(x):
    return tf.round(x) + (x - tf.round(x)) ** 3


def round_only_at_0(x):
    cond = tf.cast(tf.abs(x) < 0.5, tf.float32)
    return cond * (x ** 3) + (1 - cond) * x


def jpeg_compress_decompress(image,
                             downsample_c=True,
                             rounding=diff_round,
                             factor=1):
    image *= 255
    height, width = image.shape.as_list()[1:3]
    orig_height, orig_width = height, width
    if height % 16 != 0 or width % 16 != 0:
        # Round up to next multiple of 16
        height = ((height - 1) // 16 + 1) * 16
        width = ((width - 1) // 16 + 1) * 16

        vpad = height - orig_height
        wpad = width - orig_width
        top = vpad // 2
        bottom = vpad - top
        left = wpad // 2
        right = wpad - left

        # image = tf.pad(image, [[0, 0], [top, bottom], [left, right], [0, 0]], 'SYMMETRIC')
        image = tf.pad(image, [[0, 0], [0, vpad], [0, wpad], [0, 0]], 'SYMMETRIC')

    # "Compression"
    image = rgb_to_ycbcr_jpeg(image)
    if downsample_c:
        y, cb, cr = downsampling_420(image)
    else:
        y, cb, cr = tf.split(image, 3, axis=3)
    components = {'y': y, 'cb': cb, 'cr': cr}
    for k in components.keys():
        comp = components[k]
        comp = image_to_patches(comp)
        comp = dct_8x8(comp)
        comp = c_quantize(comp, rounding,
                          factor) if k in ('cb', 'cr') else y_quantize(
            comp, rounding, factor)
        components[k] = comp

    # "Decompression"
    for k in components.keys():
        comp = components[k]
        comp = c_dequantize(comp, factor) if k in ('cb', 'cr') else y_dequantize(
            comp, factor)
        comp = idct_8x8(comp)
        if k in ('cb', 'cr'):
            if downsample_c:
                comp = patches_to_image(comp, int(height / 2), int(width / 2))
            else:
                comp = patches_to_image(comp, height, width)
        else:
            comp = patches_to_image(comp, height, width)
        components[k] = comp

    y, cb, cr = components['y'], components['cb'], components['cr']
    if downsample_c:
        image = upsampling_420(y, cb, cr)
    else:
        image = tf.stack((y, cb, cr), axis=-1)
    image = ycbcr_to_rgb_jpeg(image)

    # Crop to original size
    if orig_height != height or orig_width != width:
        # image = image[:, top:-bottom, left:-right]
        image = image[:, :-vpad, :-wpad]

    # Hack: RGB -> YUV -> RGB sometimes results in incorrect values
    #    min_value = tf.minimum(tf.reduce_min(image), 0.)
    #    max_value = tf.maximum(tf.reduce_max(image), 255.)
    #    value_range = max_value - min_value
    #    image = 255 * (image - min_value) / value_range
    image = tf.minimum(255., tf.maximum(0., image))
    image /= 255

    return image


def quality_to_factor(quality):
    if quality < 50:
        quality = 5000. / quality
    else:
        quality = 200. - quality * 2
    return quality / 100.


def get_rand_camera_matrix(image_size, d,
                           batch_size):  # M = utils.get_rand_camera_matrix(width, np.floor(rnd_tran * 180 * 0.15), args.batch_size)
    Ms = np.zeros((batch_size, 2, 8))
    fx = 400
    fy = 400
    cx = 200
    cy = 200
    for num in range(batch_size):
        # rotation matrix
        # (alpha, beta, gamma) = np.random.uniform(-np.pi/90, np.pi/90, 3).astype(np.float32)
        (alpha, beta, gamma) = np.random.uniform(-d / 180, d / 180, 3).astype(np.float32)
        rot_matrix = np.zeros((3, 3), dtype=np.float32)
        rot_matrix[0][0] = np.cos(beta) * np.cos(gamma)
        rot_matrix[0][1] = np.cos(beta) * np.sin(gamma)
        rot_matrix[0][2] = -np.sin(beta)
        rot_matrix[1][0] = np.sin(alpha) * np.sin(beta) * np.cos(gamma) - np.cos(alpha) * np.sin(gamma)
        rot_matrix[1][1] = np.sin(alpha) * np.sin(beta) * np.sin(gamma) + np.cos(alpha) * np.cos(gamma)
        rot_matrix[1][2] = np.sin(alpha) * np.cos(beta)
        rot_matrix[2][0] = np.cos(alpha) * np.sin(beta) * np.cos(gamma) + np.sin(alpha) * np.sin(gamma)
        rot_matrix[2][1] = np.cos(alpha) * np.sin(beta) * np.sin(gamma) - np.sin(alpha) * np.cos(gamma)
        rot_matrix[2][2] = np.cos(alpha) * np.cos(beta)
        # rot_matrix_inv = np.linalg.inv(rot_matrix)
        # point(0,0)
        i = 0
        j = 0
        x = (j - cx) / fx
        y = (i - cy) / fy
        z = 1
        point_3D = np.array([x, y, z])
        point_3D = np.transpose(point_3D)
        oldpoint_3D = np.matmul(rot_matrix, point_3D)
        oldx = oldpoint_3D[0]
        oldy = oldpoint_3D[1]
        oldz = oldpoint_3D[2]
        u_0 = (fx * oldx + cx * oldz) / oldz
        v_0 = (fy * oldy + cy * oldz) / oldz
        # point(400,0)
        i = 0
        j = image_size
        x = (j - cx) / fx
        y = (i - cy) / fy
        z = 1
        point_3D = np.array([x, y, z])
        point_3D = np.transpose(point_3D)
        oldpoint_3D = np.matmul(rot_matrix, point_3D)
        oldx = oldpoint_3D[0]
        oldy = oldpoint_3D[1]
        oldz = oldpoint_3D[2]
        u_1 = (fx * oldx + cx * oldz) / oldz
        v_1 = (fy * oldy + cy * oldz) / oldz
        # point(400,400)
        i = image_size
        j = image_size
        x = (j - cx) / fx
        y = (i - cy) / fy
        z = 1
        point_3D = np.array([x, y, z])
        point_3D = np.transpose(point_3D)
        oldpoint_3D = np.matmul(rot_matrix, point_3D)
        oldx = oldpoint_3D[0]
        oldy = oldpoint_3D[1]
        oldz = oldpoint_3D[2]
        u_2 = (fx * oldx + cx * oldz) / oldz
        v_2 = (fy * oldy + cy * oldz) / oldz
        # point(0,400)
        i = image_size
        j = 0
        x = (j - cx) / fx
        y = (i - cy) / fy
        z = 1
        point_3D = np.array([x, y, z])
        point_3D = np.transpose(point_3D)
        oldpoint_3D = np.matmul(rot_matrix, point_3D)
        oldx = oldpoint_3D[0]
        oldy = oldpoint_3D[1]
        oldz = oldpoint_3D[2]
        u_3 = (fx * oldx + cx * oldz) / oldz
        v_3 = (fy * oldy + cy * oldz) / oldz

        rect = np.array([
            [u_0, v_0],
            [u_1, v_1],
            [u_2, v_2],
            [u_3, v_3]], dtype="float32")
        # print(rect)
        dst = np.array([
            [0, 0],
            [image_size, 0],
            [image_size, image_size],
            [0, image_size]], dtype="float32")

        M = cv2.getPerspectiveTransform(rect, dst)
        M_inv = np.linalg.inv(M)
        Ms[num, 0, :] = M_inv.flatten()[:8]
        Ms[num, 1, :] = M.flatten()[:8]
    return Ms


def get_rand_warp_matrix(sx, sy, min_x, min_y, angle, min_zoom, max_zoom, batch_size):
    rad = (angle * np.pi) / 180.0
    tx = np.random.uniform(-min_x, min_x, (batch_size, 1)).astype(np.float32)
    ty = np.random.uniform(-min_y, min_y, (batch_size, 1)).astype(np.float32)
    r = np.random.uniform(-rad, rad, (batch_size, 1)).astype(np.float32)
    z = np.random.uniform(min_zoom, max_zoom, (batch_size, 1)).astype(np.float32)
    hx = np.random.uniform(-rad, rad, (batch_size, 1)).astype(np.float32)
    hy = np.random.uniform(-rad, rad, (batch_size, 1)).astype(np.float32)

    a = hx - r
    b = hx + r
    T1 = (z * np.cos(a)) / (np.cos(hx))
    T2 = (z * np.sin(a)) / (np.cos(hx))
    T3 = (sx * np.cos(hx) - sx * z * np.cos(a) + 2 * tx * z * np.cos(a) - sy * z * np.sin(a) + 2 * ty * z * np.sin(
        a)) / (2 * np.cos(hx))
    T4 = (z * np.sin(b)) / (np.cos(hy))
    T5 = (z * np.cos(b)) / (np.cos(hy))
    T6 = (sy * np.cos(hy) - sy * z * np.cos(b) + 2 * ty * z * np.cos(b) - sx * z * np.sin(b) + 2 * tx * z * np.sin(
        b)) / (2 * np.cos(hy))
    T7 = np.zeros((batch_size, 2)).astype(np.float32)

    T = np.concatenate((T1, T2, T3, T4, T5, T6, T7), axis=1)

    return T


def weights_init(m):
    classname = m.__class__.__name__
    if hasattr(m, 'weight') and (classname.find('Conv') != -1 or classname.find('Linear') != -1):
        init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
        if hasattr(m, 'bias') and m.bias is not None:
            init.constant_(m.bias.data, 0.0)
    elif classname.find('BatchNorm') != -1:
        torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
        torch.nn.init.constant_(m.bias.data, 0.0)


def same_seeds(seed):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)  # if you are using multi-GPU.
    np.random.seed(seed)  # Numpy module.
    random.seed(seed)  # Python random module.
    torch.backends.cudnn.benchmark = True  # False
    torch.backends.cudnn.deterministic = True


def get_secret_acc(secret_pred, secret_true):
    # 比特精确度,和秘密消息正确率
    if 'cuda' in str(secret_pred.device):
        secret_pred = secret_pred.cpu()
        secret_true = secret_true.cpu()
    secret_pred = torch.abs(torch.round(secret_pred).clip(0, 1))
    correct_pred = torch.sum((secret_pred - secret_true) == 0, dim=1)
    str_acc = 1.0 - torch.sum((correct_pred - secret_pred.size()[1]) != 0).numpy() / correct_pred.size()[0]
    bit_acc = torch.sum(correct_pred).numpy() / secret_pred.numel()  # numel()函数：返回数组中元素的个数
    return bit_acc


def get_rand_homography_mat(img, eps=0.2):
    batch_size = img.shape[0]
    res = np.zeros((batch_size, 2, 3, 3))

    h, w = img.shape[2:4]
    eps_x = w * eps
    eps_y = h * eps
    for i in range(batch_size):
        top_left_x = random.uniform(-eps_x, eps_x)
        top_left_y = random.uniform(-eps_y, eps_y)
        bottom_left_x = random.uniform(-eps_x, eps_x)
        bottom_left_y = random.uniform(-eps_y, eps_y)
        top_right_x = random.uniform(-eps_x, eps_x)
        top_right_y = random.uniform(-eps_y, eps_y)
        bottom_right_x = random.uniform(-eps_x, eps_x)
        bottom_right_y = random.uniform(-eps_y, eps_y)

        rect = np.array([
            [top_left_x, top_left_y],
            [top_right_x + w, top_right_y],
            [bottom_right_x + w, bottom_right_y + h],
            [bottom_left_x, bottom_left_y + h]], dtype="float32")

        dst = np.array([
            [0, 0],
            [w, 0],
            [w, h],
            [0, h]], dtype="float32")

        res_i = cv2.getPerspectiveTransform(rect, dst)
        res_i_inv = np.linalg.inv(res_i)

        res[i, 0, :, :] = res_i
        res[i, 1, :, :] = res_i_inv
    return res


def get_warped_points_and_gap(source_points: np.ndarray, homography: torch.tensor, ):
    device = homography.device
    nums = len(source_points)
    source_points_ = source_points.reshape((1, nums, 2))
    warped_points = []
    gaps = []
    for i in range(len(homography)):
        H = homography[i, 0].cpu().numpy()
        H_inverse = homography[i, 1].cpu().numpy()
        warped_point = cv2.perspectiveTransform(np.float32(source_points_), H_inverse).reshape(-1, 2)
        gap = torch.from_numpy(np.subtract(np.array(warped_point), np.array(source_points)))
        gaps.append(gap)
        warped_points.append(warped_point)
    targets = torch.stack(gaps, dim=0).float().to(device)
    points = np.stack(warped_points, axis=0)
    return targets, points


def get_min_max_scale_extract(batch: torch.tensor):
    res = []
    device = batch.device
    for i in range(len(batch)):
        temp = (batch[i] - torch.min(batch[i])) / (torch.max(batch[i]) - torch.min(batch[i]))
        res.append(temp)
    return torch.stack(res, dim=0).to(device)


def get_warped_extracted_IMG(images, masks, args, isMul=True, isHomography=True, isResize=True):
    device = images.device
    if isHomography:
        h, w = images.shape[2:4]
        homography = get_rand_homography_mat(images)
        homography = torch.from_numpy(homography).float().to(device)

        transformDec = torchgeometry.warp_perspective(images, homography[:, 1, :, :], dsize=(h, w))
        transformDec = torchgeometry.warp_perspective(transformDec, homography[:, 0, :, :], dsize=(h, w))
        transformMask = torchgeometry.warp_perspective(masks, homography[:, 1, :, :], dsize=(h, w))
        transformMask = torchgeometry.warp_perspective(transformMask, homography[:, 0, :, :], dsize=(h, w))
        transformMask[transformMask > 0] = 1.0
    else:
        transformDec, transformMask = images, masks

    waitDec = []
    for img, mask in zip(transformDec, transformMask):
        if len(torch.unique(mask)) == 1 and torch.unique(mask)[0] == 0:
            return None
        index = torch.where(mask == 1)
        h_min, h_max = torch.min(index[1]), torch.max(index[1])
        w_min, w_max = torch.min(index[2]), torch.max(index[2])

        partialIMG = img[:, h_min:h_max, w_min:w_max].clone()
        partialMask = mask[:, h_min:h_max, w_min:w_max].clone()
        partialIMG = partialIMG.unsqueeze(0)
        partialMask = partialMask.unsqueeze(0)

        assert partialIMG.shape == partialMask.shape

        if isMul:
            dec = partialIMG * partialMask
        else:
            dec = partialIMG
        if isResize:
            dec = F.interpolate(dec, size=(args.extract_size, args.extract_size), )
        waitDec.append(dec)

    return torch.cat(waitDec, dim=0)


def extractIMG(images, masks, args, isMul=True, isHomography=True, isResize=True, isBack=True):
    waitDec = []
    device = images.device

    for img, mask in zip(images, masks):
        if len(torch.unique(mask)) == 1 and torch.unique(mask)[0] == 0:
            return None
        index = torch.where(mask == 1)
        h_min, h_max = torch.min(index[1]), torch.max(index[1])
        w_min, w_max = torch.min(index[2]), torch.max(index[2])

        partialIMG = img[:, h_min:h_max, w_min:w_max].clone()
        partialMask = mask[:, h_min:h_max, w_min:w_max].clone()
        partialIMG = partialIMG.unsqueeze(0)
        partialMask = partialMask.unsqueeze(0)

        assert partialIMG.shape == partialMask.shape
        h, w = partialIMG.shape[2:4]
        # print(h, w)
        if isHomography:
            homography = get_rand_homography_mat(partialIMG)
            homography = torch.from_numpy(homography).float().to(device)
            transformDec = torchgeometry.warp_perspective(partialIMG, homography[:, 1, :, :], dsize=(h, w))
            transformMask = torchgeometry.warp_perspective(partialMask, homography[:, 1, :, :], dsize=(h, w))
            if isBack:
                transformDec = torchgeometry.warp_perspective(transformDec, homography[:, 0, :, :], dsize=(h, w))
                transformMask = torchgeometry.warp_perspective(transformMask, homography[:, 0, :, :], dsize=(h, w))
                transformMask[transformMask > 0] = 1.0
        else:
            transformDec, transformMask = partialIMG, partialMask

        if isMul:
            dec = transformDec * transformMask
        else:
            dec = transformDec
        if isResize:
            dec = F.interpolate(dec, size=(args.extract_size, args.extract_size))
        waitDec.append(dec)

    return torch.cat(waitDec, dim=0)
    # return waitDec


def extract_img_mask(images, masks, extract_size=256, isMul=False, isResize=True):
    waitDec = []
    waitMask = []

    device = images.device

    for img, mask in zip(images, masks):
        if len(torch.unique(mask)) == 1 and torch.unique(mask)[0] == 0:
            return None
        index = torch.where(mask == 1)
        h_min, h_max = torch.min(index[1]), torch.max(index[1])
        w_min, w_max = torch.min(index[2]), torch.max(index[2])

        partialIMG = img[:, h_min:h_max, w_min:w_max].clone()
        partialMask = mask[:, h_min:h_max, w_min:w_max].clone()
        partialIMG = partialIMG.unsqueeze(0)
        partialMask = partialMask.unsqueeze(0)

        assert partialIMG.shape == partialMask.shape
        h, w = partialIMG.shape[2:4]
        # print(h, w)

        transformDec, transformMask = partialIMG, partialMask

        if isMul:
            dec = transformDec * transformMask
        else:
            dec = transformDec
        if isResize:
            dec = F.interpolate(dec, size=(extract_size, extract_size))
            mk = F.interpolate(transformMask, size=(extract_size, extract_size))
            mk[mk > 0] = 1.0
            waitMask.append(mk)
            print(dec.shape, mk.shape)

    return torch.cat(waitDec, dim=0).to(device), torch.cat(waitMask, dim=0).to(device)
    # return waitDec


def tensor2im(image_tensor, imtype=np.uint8, normalize=False, is255=False):
    if isinstance(image_tensor, list):
        image_numpy = []
        for i in range(len(image_tensor)):
            image_numpy.append(tensor2im(image_tensor[i], imtype, normalize))
        return image_numpy
    image_numpy = image_tensor.squeeze(0).detach().cpu().float().numpy()
    if not is255:
        if normalize:
            image_numpy = (np.transpose(image_numpy, (1, 2, 0)) + 1) / 2.0 * 255.0
        else:
            image_numpy = np.transpose(image_numpy, (1, 2, 0)) * 255.0
    else:
        image_numpy = np.transpose(image_numpy, (1, 2, 0))
    image_numpy = np.clip(image_numpy, 0, 255)
    if image_numpy.shape[2] == 1 or image_numpy.shape[2] > 3:
        image_numpy = image_numpy[:, :, 0]
    return image_numpy.astype(imtype)


def im2tensor(img):
    assert type(img) == np.ndarray, 'the img type is {}, but ndarry expected'.format(type(img))
    # img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = torch.from_numpy(img.transpose((2, 0, 1)))
    return img.float().div(255).unsqueeze(0)  # 255也可以改为256


def min_max_scale(num):
    return (num - np.min(num)) / (np.max(num) - np.min(num))


def print_network(net):
    num_params = 0
    for param in net.parameters():
        num_params += param.numel()
    print(net)
    print('Total number of parameters: %d' % num_params)


def get_cdos(img, dos_num=9):
    h, w = img.shape[2:4]
    cdos = None
    # # 8个点
    # top_left = [temp_w, temp_h]
    # top_mid = [temp_w * 2, temp_h]
    # top_right = [temp_w * 3, temp_h]
    # mid_left = [temp_w, temp_h * 2]
    # mid_right = [temp_w * 3, temp_h * 2]
    # bottom_left = [temp_w, temp_h * 3]
    # bottom_mid = [temp_w * 2, temp_h * 3]
    # bottom_right = [temp_w * 3, temp_h * 3]
    # cdos = np.array([top_left, top_mid, top_right, mid_right, bottom_right, bottom_mid, bottom_left, mid_left])
    if dos_num == 9:
        # 9个点
        ex_h = int(h // 2)
        ex_w = int(w // 2)
        temp_h = max(int(ex_h // 3) - 12, 2)
        temp_w = max(int(ex_w // 3) - 12, 2)
        top_left = [temp_w, temp_h]
        top_mid = [temp_w * 2, temp_h]
        top_right = [temp_w * 3, temp_h]
        mid_left = [temp_w, temp_h * 2]
        mid_mid = [temp_w * 2, temp_h * 2]
        mid_right = [temp_w * 3, temp_h * 2]
        bottom_left = [temp_w, temp_h * 3]
        bottom_mid = [temp_w * 2, temp_h * 3]
        bottom_right = [temp_w * 3, temp_h * 3]
        cdos = np.array([top_left, top_mid, top_right, mid_right, bottom_right, bottom_mid, bottom_left, mid_left, mid_mid])
    elif dos_num == 4:
        # 4个点
        ex_h = int(h // 6) - h // 25
        ex_w = int(w // 6) - w // 25
        temp_h = max(ex_h, 2)
        temp_w = max(ex_w, 2)
        top_left = [temp_w, temp_h]
        top_right = [temp_w * 3, temp_h]
        bottom_left = [temp_w, temp_h * 3]
        bottom_right = [temp_w * 3, temp_h * 3]
        cdos = np.array([top_left, top_right, bottom_right, bottom_left])
    return cdos


def get_cdos_according_mask(images, masks):
    cdos = []
    device = images.device

    for img, mask in zip(images, masks):
        if len(torch.unique(mask)) == 1 and torch.unique(mask)[0] == 0:
            return None
        index = torch.where(mask == 1)
        h_min, h_max = torch.min(index[1]), torch.max(index[1])
        w_min, w_max = torch.min(index[2]), torch.max(index[2])
        h = h_max - h_min
        w = w_max - w_min
        ex_h = int(h // 6.5)
        ex_w = int(w // 6.5)
        temp_h = max(ex_h, 2)
        temp_w = max(ex_w, 2)
        top_left = [w_min // 4 + temp_w, h_min // 4 + temp_h]
        top_mid = [w_min // 4 + temp_w * 2, h_min // 4 + temp_h]
        top_right = [w_min // 4 + temp_w * 3, h_min // 4 + temp_h]
        mid_left = [w_min // 4 + temp_w, h_min // 4 + temp_h * 2]
        mid_mid = [w_min // 4 + temp_w * 2, h_min // 4 + temp_h * 2]
        mid_right = [w_min // 4 + temp_w * 3, h_min // 4 + temp_h * 2]
        bottom_left = [w_min // 4 + temp_w, h_min // 4 + temp_h * 3]
        bottom_mid = [w_min // 4 + temp_w * 2, h_min // 4 + temp_h * 3]
        bottom_right = [w_min // 4 + temp_w * 3, h_min // 4 + temp_h * 3]
        cdo = np.array([top_left, top_mid, top_right, mid_right, bottom_right, bottom_mid, bottom_left, mid_left, mid_mid])
        cdos.append(cdo)
    return cdos


def Random_noise(inputs, noise_factor=0.15):
    device = inputs.device
    noise = torch.rand(inputs.shape) * noise_factor
    noisy = inputs + noise.to(device)
    noisy = torch.clip(noisy, 0., 1.)
    return noisy


def Gauss_noise(img, rnd_noise):
    device = img.device
    # rnd_noise = torch.rand(1)[0] * rnd_noise  # rnd_noise:0.02
    noise = torch.normal(mean=0, std=rnd_noise, size=img.size(), dtype=torch.float32)
    if torch.cuda.is_available():
        noise = noise.to(device)
    img = img + noise  # 实际上也就是原图+噪音
    img = torch.clamp(img, 0, 1)
    return img


def get_color_distortion(s=1.0):
    # s is the strength of color distortion.
    # brightness=0, contrast=0, saturation=0, hue=0
    color_jitter = transforms.ColorJitter(0.8 * s, 0.8 * s, 0.8 * s, 0.2 * s)
    rnd_color_jitter = transforms.RandomApply([color_jitter], p=0.8)
    rnd_gray = transforms.RandomGrayscale(p=0.2)
    color_distort = transforms.Compose([
        rnd_color_jitter,
        rnd_gray])

    return color_distort


# 1. RGB -> YCbCr
class rgb_to_ycbcr_jpeg(nn.Module):
    """ Converts RGB image to YCbCr
    Input:
        image(tensor): batch x 3 x height x width
    Outpput:
        result(tensor): batch x height x width x 3
    """

    def __init__(self):
        super(rgb_to_ycbcr_jpeg, self).__init__()
        matrix = np.array(
            [[0.299, 0.587, 0.114],
             [-0.168736, -0.331264, 0.5],
             [0.5, -0.418688, -0.081312]], dtype=np.float32).T
        self.shift = torch.tensor([0., 128., 128.])  # nn.Parameter(
        self.matrix = torch.from_numpy(matrix)

    def forward(self, x):
        image = (x * 255).permute(0, 2, 3, 1)  # 转为batch*h*w*c的格式
        result = torch.tensordot(image, self.matrix, dims=1) + self.shift
        result = result.reshape(x.shape)
        result = torch.clamp(result, 0, 255)
        return result  # b*h*w*3


class ycbcr_to_rgb_jpeg(nn.Module):
    """ Converts YCbCr image to RGB JPEG
    Input:
        image(tensor): batch x height x width x 3
    Outpput:
        result(tensor): batch x 3 x height x width
    """

    def __init__(self):
        super(ycbcr_to_rgb_jpeg, self).__init__()

        matrix = np.array(
            [[1., 0., 1.402], [1, -0.344136, -0.714136], [1, 1.772, 0]],
            dtype=np.float32).T
        self.shift = torch.tensor([0, -128., -128.])  # nn.Parameter
        self.matrix = torch.from_numpy(matrix)

    def forward(self, x):
        image = x.permute(0, 2, 3, 1)  # 转为batch*h*w*c的格式
        result = torch.tensordot(image + self.shift, self.matrix, dims=1)
        result = result.reshape(x.shape)
        result = torch.clamp(result, 0, 255) / 255
        return result  # batch*c*h*w


def convert_rgb_to_ycbcr(x):
    """
            RGB转YCBCR
            Y=0.257*R+0.564*G+0.098*B+16
            Cb=-0.148*R-0.291*G+0.439*B+128
            Cr=0.439*R-0.368*G-0.071*B+128
    """
    # img = x * 255
    img = x
    device = img.device
    if type(img) == torch.Tensor:
        if len(img.shape) == 3:
            img = img.unsqueeze(0)
        # y = 16. + (0.257 * img[:, 0, :, :].unsqueeze(1) + 0.564 * img[:, 1, :, :].unsqueeze(1) + 0.098 * img[:, 2, :, :].unsqueeze(1))
        # cb = 128. + (-0.148 * img[:, 0, :, :].unsqueeze(1) - 0.291 * img[:, 1, :, :].unsqueeze(1) + 0.439 * img[:, 2, :, :].unsqueeze(1))
        # cr = 128. + (0.439 * img[:, 0, :, :].unsqueeze(1) - 0.368 * img[:, 1, :, :].unsqueeze(1) - 0.071 * img[:, 2, :, :].unsqueeze(1))

        y = 0.299 * img[:, 0, :, :].unsqueeze(1) + 0.587 * img[:, 1, :, :].unsqueeze(1) + 0.114 * img[:, 2, :, :].unsqueeze(1)
        cr = (img[:, 0, :, :].unsqueeze(1) - y) * 0.713 + 0.5
        cb = (img[:, 2, :, :].unsqueeze(1) - y) * 0.564 + 0.5

        # y = 0.2990 * img[:, 0, :, :].unsqueeze(1) + 0.587 * img[:, 1, :, :].unsqueeze(1) + 0.114 * img[:, 2, :, :].unsqueeze(1)
        # cb = -0.1687 * img[:, 0, :, :].unsqueeze(1) - 0.3313 * img[:, 1, :, :].unsqueeze(1) + 0.5 * img[:, 2, :, :].unsqueeze(1)
        # cr = 0.5 * img[:, 0, :, :].unsqueeze(1) - 0.4187 * img[:, 1, :, :].unsqueeze(1) - 0.0813 * img[:, 2, :, :].unsqueeze(1)
        return torch.cat([y, cb, cr], 1).to(device)  # .permute(1, 2, 0)
    else:
        raise Exception('Unknown Type', type(img))


def convert_ycbcr_to_rgb(x):
    """
            YCBCR转RGB
            R=1.164*(Y-16)+1.596*(Cr-128)
            G=1.164*(Y-16)-0.392*(Cb-128)-0.813*(Cr-128)
            B=1.164*(Y-16)+2.017*(Cb-128)
    """
    device = x.device
    # img = x * 255
    img = x
    if type(img) == torch.Tensor:
        if len(img.shape) == 3:
            img = img.unsqueeze(0)
        # r = 1.164 * (img[:, 0, :, :].unsqueeze(1) - 16) + 1.596 * (img[:, 2, :, :].unsqueeze(1) - 128)
        # g = 1.164 * (img[:, 0, :, :].unsqueeze(1) - 16) - 0.392 * (img[:, 1, :, :].unsqueeze(1) - 128) - 0.813 * (img[:, 2, :, :].unsqueeze(1) - 128)
        # b = 1.164 * (img[:, 0, :, :].unsqueeze(1) - 16) + 2.017 * (img[:, 1, :, :].unsqueeze(1) - 128)

        b = (img[:, 1, :, :].unsqueeze(1) - 0.5) * 1. / 0.564 + img[:, 0, :, :].unsqueeze(1)
        r = (img[:, 2, :, :].unsqueeze(1) - 0.5) * 1. / 0.713 + img[:, 0, :, :].unsqueeze(1)
        g = 1. / 0.587 * (img[:, 0, :, :].unsqueeze(1) - 0.299 * r - 0.114 * b)

        return (torch.cat([r, g, b], 1)).to(device)
    else:
        raise Exception('Unknown Type', type(img))


class RgbYcbcr(nn.Module):
    def __init__(self):
        super(RgbYcbcr, self).__init__()
        self.Ycbcr = nn.Conv2d(3, 3, 1, 1, bias=False)
        trans_matrix = np.array([[0.299, 0.587, 0.114],
                                 [-0.168736, -0.331264, 0.5],
                                 [0.5, -0.418688, -0.081312]])
        trans_matrix = torch.from_numpy(trans_matrix).float().unsqueeze(2).unsqueeze(3)
        self.Ycbcr.weight.data = trans_matrix
        self.Ycbcr.weight.requires_grad = False

        self.reYcbcr = nn.Conv2d(3, 3, 1, 1, bias=False)
        re_matrix = np.linalg.pinv(np.array([[0.299, 0.587, 0.114],
                                             [-0.168736, -0.331264, 0.5],
                                             [0.5, -0.418688, -0.081312]]))
        re_matrix = torch.from_numpy(re_matrix).float().unsqueeze(2).unsqueeze(3)
        self.reYcbcr.weight.data = re_matrix

    def forward(self, x):
        ycbcr = self.Ycbcr(x)  # b 3 h w
        return ycbcr

    def reverse(self, x):
        rgb = self.reYcbcr(x)
        return rgb


def rgb2ycbcr_tensor(imgs):
    device = imgs.device
    b = imgs.shape[0]
    res = []
    for i in range(b):
        # tensor->ndarray->ycbcr->tensor
        tmp = im2tensor(cv2.cvtColor(tensor2im(imgs[i].clone().unsqueeze(0)), cv2.COLOR_RGB2YCrCb))
        res.append(tmp)
    return torch.cat(res, dim=0).to(device)


def ycbcr2rgb_tensor(imgs):
    device = imgs.device
    b = imgs.shape[0]
    res = []
    for i in range(b):
        # tensor->ndarray->rgb->tensor
        tmp = im2tensor(cv2.cvtColor(tensor2im(imgs[i].clone().unsqueeze(0)), cv2.COLOR_YCrCb2RGB))
        res.append(tmp)
    return torch.cat(res, dim=0).to(device)


def calc_psnr(img1, img2):
    return 10. * torch.log10(1. / torch.mean((img1 - img2) ** 2))


def generate_random_key(l=30):
    s = string.ascii_lowercase + string.digits
    return ''.join(random.sample(s, l))
