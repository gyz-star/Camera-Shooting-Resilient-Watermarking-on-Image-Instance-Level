import random

import cv2
import numpy as np
import torch
import torchvision
from torch import nn

import lpips_tf
import tensorflow as tf
# import tensorflow.compat.v1 as tf
import utils
from tensorflow.python.keras.models import *
from tensorflow.python.keras.layers import *


# from keras.layers import *
# from keras.models import *
# from stn import spatial_transformer_network as stn_transformer


class StegaStampEncoder(Layer):
    def __init__(self, height, width):
        super(StegaStampEncoder, self).__init__()
        # 全连接层+relu，输出维度7500，初始化是正态分布
        self.secret_dense = Dense(7500, activation='relu', kernel_initializer='he_normal')
        # 卷积层，输出通道数为32，卷积核为3*3，输出的大小保持不变
        self.conv1 = Conv2D(32, 3, activation='relu', padding='same', kernel_initializer='he_normal')
        # 卷积层，输出通道数为32，卷积核为3*3，输出的大小保持不变，步长为2
        self.conv2 = Conv2D(32, 3, activation='relu', strides=2, padding='same', kernel_initializer='he_normal')
        self.conv3 = Conv2D(64, 3, activation='relu', strides=2, padding='same', kernel_initializer='he_normal')
        self.conv4 = Conv2D(128, 3, activation='relu', strides=2, padding='same', kernel_initializer='he_normal')
        self.conv5 = Conv2D(256, 3, activation='relu', strides=2, padding='same', kernel_initializer='he_normal')
        self.up6 = Conv2D(128, 2, activation='relu', padding='same', kernel_initializer='he_normal')
        self.conv6 = Conv2D(128, 3, activation='relu', padding='same', kernel_initializer='he_normal')
        self.up7 = Conv2D(64, 2, activation='relu', padding='same', kernel_initializer='he_normal')
        self.conv7 = Conv2D(64, 3, activation='relu', padding='same', kernel_initializer='he_normal')
        self.up8 = Conv2D(32, 2, activation='relu', padding='same', kernel_initializer='he_normal')
        self.conv8 = Conv2D(32, 3, activation='relu', padding='same', kernel_initializer='he_normal')
        self.up9 = Conv2D(32, 2, activation='relu', padding='same', kernel_initializer='he_normal')
        self.conv9 = Conv2D(32, 3, activation='relu', padding='same', kernel_initializer='he_normal')
        self.conv10 = Conv2D(32, 3, activation='relu', padding='same', kernel_initializer='he_normal')
        self.residual = Conv2D(3, 1, activation=None, padding='same', kernel_initializer='he_normal')

    def call(self, inputs):
        secret, image = inputs
        # 减去0.5
        secret = secret - .5
        image = image - .5
        # 消息输入全连接层
        secret = self.secret_dense(secret)
        # 一维变三维
        secret = Reshape((50, 50, 3))(secret)
        # 上采样，放大八倍
        secret_enlarged = UpSampling2D(size=(8, 8))(secret)
        # 通道维度拼接
        # 大概就是一个u-net结构
        inputs = concatenate([secret_enlarged, image], axis=-1)
        conv1 = self.conv1(inputs)
        conv2 = self.conv2(conv1)
        conv3 = self.conv3(conv2)
        conv4 = self.conv4(conv3)
        conv5 = self.conv5(conv4)
        up6 = self.up6(UpSampling2D(size=(2, 2))(conv5))
        # 维度下标从0开始，3就是通道维度
        merge6 = concatenate([conv4, up6], axis=3)
        conv6 = self.conv6(merge6)
        up7 = self.up7(UpSampling2D(size=(2, 2))(conv6))
        merge7 = concatenate([conv3, up7], axis=3)
        conv7 = self.conv7(merge7)
        up8 = self.up8(UpSampling2D(size=(2, 2))(conv7))
        merge8 = concatenate([conv2, up8], axis=3)
        conv8 = self.conv8(merge8)
        up9 = self.up9(UpSampling2D(size=(2, 2))(conv8))
        # 为什么要连接inputs
        merge9 = concatenate([conv1, up9, inputs], axis=3)
        conv9 = self.conv9(merge9)
        conva = self.conv9(merge9)
        conv10 = self.conv10(conv9)
        residual = self.residual(conv9)
        return residual


class StegaStampDecoder(Layer):
    def __init__(self, secret_size, height, width):
        super(StegaStampDecoder, self).__init__()
        self.height = height
        self.width = width
        loc_in = self.height * self.width * 3
        loc_out = 6
        initial = np.array([[1., 0, 0], [0, 1., 0]])
        initial = initial.astype('float32').flatten()

        # Variable(initializer, name), 参数initializer是初始化参数，name是可自定义的变量名称
        # 自定义的参数和卷积层的参数会一起更新吗
        # 感觉是弃用的，或者可更改
        self.W_fc1 = tf.Variable(tf.zeros([loc_in, loc_out]), name='W_fc1')
        self.b_fc1 = tf.Variable(initial_value=initial, name='b_fc1')
        '''
        self.stn_params = Sequential([
            Conv2D(32, (3, 3), strides=2, activation='relu', padding='same'),
            Conv2D(64, (3, 3), strides=2, activation='relu', padding='same'),
            Conv2D(128, (3, 3), strides=2, activation='relu', padding='same'),
            Flatten(),
            Dense(128, activation='relu')
        ])
        initial = np.array([[1., 0, 0], [0, 1., 0]])
        initial = initial.astype('float32').flatten()
        self.W_fc1 = tf.Variable(tf.zeros([128, 6]), name='W_fc1')
        self.b_fc1 = tf.Variable(initial_value=initial, name='b_fc1')
        '''
        self.decoder = Sequential([
            Conv2D(32, (3, 3), strides=2, activation='relu', padding='same'),
            Conv2D(32, (3, 3), activation='relu', padding='same'),
            Conv2D(64, (3, 3), strides=2, activation='relu', padding='same'),
            Conv2D(64, (3, 3), activation='relu', padding='same'),
            Conv2D(64, (3, 3), strides=2, activation='relu', padding='same'),
            Conv2D(128, (3, 3), strides=2, activation='relu', padding='same'),
            Conv2D(128, (3, 3), strides=2, activation='relu', padding='same'),
            Flatten(),
            Dense(512, activation='relu'),
            Dense(secret_size)
        ])

    def call(self, image):
        image = image - .5
        return self.decoder(image), image
        # print('transformed image:',image)
        # stn_params = self.stn_params(image)
        # x = tf.matmul(stn_params, self.W_fc1) + self.b_fc1
        # image_flatten = tf.layers.flatten(image)
        # print('flat transformed image:',image_flatten)
        # x = tf.matmul(image_flatten, self.W_fc1) + self.b_fc1
        # stn_image = stn_transformer(image, x, [self.height, self.width, 3])
        # return self.decoder(stn_image), stn_image


# 有很大的困惑为什么encoder是unet，decoder是直筒的
# 为什么要这样设计

class Discriminator(Layer):
    def __init__(self):
        super(Discriminator, self).__init__()
        self.model = Sequential([
            Conv2D(8, (3, 3), strides=2, activation='relu', padding='same'),
            Conv2D(16, (3, 3), strides=2, activation='relu', padding='same'),
            Conv2D(32, (3, 3), strides=2, activation='relu', padding='same'),
            Conv2D(64, (3, 3), strides=2, activation='relu', padding='same'),
            Conv2D(1, (3, 3), activation=None, padding='same')
        ])

    def call(self, image):
        x = image - .5
        x = self.model(x)
        output = tf.reduce_mean(x)
        return output, x


class MaskRCNN(nn.Module):
    def __init__(self, threshold=0.75):
        super(MaskRCNN, self).__init__()
        self.threshold = threshold
        self.model = torchvision.models.detection.maskrcnn_resnet50_fpn(pretrained=True)
        self.random_colour_masks = self.random_colour_masks
        for param in self.model.parameters():
            param.requires_grad = False

    def forward(self, img):
        device = img.device

        output = self.model(img)
        result_mask = []
        isNone = False
        for num, each_mask in enumerate(output):
            pred_score = list(each_mask['scores'].cpu().detach().numpy())
            pred_t = [pred_score.index(x) for x in pred_score if x > self.threshold]
            if len(pred_t) == 0:
                isNone = True
                break
            pred_t = pred_t[-1]
            masks = (each_mask['masks'] > 0.5).squeeze(1).detach().cpu().numpy()
            masks = masks[:pred_t + 1]
            masks = torch.tensor(masks)
            _, idx = torch.sum(masks, dim=[1, 2]).max(0)  # 最大语义区域max,最小语义区域min
            idx = idx.item()
            rgb_mask = self.random_colour_masks(masks[idx])
            # print(rgb_mask.shape)
            mask = cv2.cvtColor(rgb_mask, cv2.COLOR_RGB2GRAY)
            _, mask = cv2.threshold(mask, 0, 1, cv2.THRESH_BINARY, cv2.THRESH_OTSU)
            out = torch.tensor(np.stack([mask, mask, mask], axis=0)).to(device)
            out = out * 1.0
            result_mask.append(out)
        if isNone:
            return None
        result = torch.stack(result_mask, dim=0)
        result = result.to(device)
        return result

    @staticmethod
    def random_colour_masks(image):
        colours = [[0, 255, 0], [0, 0, 255], [255, 0, 0], [0, 255, 255], [255, 255, 0], [255, 0, 255], [80, 70, 180],
                   [250, 80, 190], [245, 145, 50],
                   [70, 150, 250], [50, 190, 190]]
        r = np.zeros_like(image).astype(np.uint8)
        g = np.zeros_like(image).astype(np.uint8)
        b = np.zeros_like(image).astype(np.uint8)
        r[image == 1], g[image == 1], b[image == 1] = colours[random.randrange(0, 10)]
        coloured_mask = np.stack([r, g, b], axis=2)
        return coloured_mask


# 就是对encoded_image变换s
def transform_net(encoded_image, args, global_step, batch_size):
    sh = tf.shape(encoded_image)
    # lambda相当于声明一个函数ramp_fn（ramp）
    # global_step除ramp，与1比，取最小
    ramp_fn = lambda ramp: tf.minimum(tf.to_float(global_step) / ramp, 1.)
    # rnd_bri_ramp, rnd_hue_ramp，default=1000。
    # rnd_bri，default=.3
    # rnd_hue',default=.1
    # 得到一个数，bri亮度，hue色调
    rnd_bri = ramp_fn(args.rnd_bri_ramp) * args.rnd_bri
    rnd_hue = ramp_fn(args.rnd_hue_ramp) * args.rnd_hue
    # 返回形状为(batch_size,1,1,3)
    rnd_brightness = utils.get_rnd_brightness_tf(rnd_bri, rnd_hue, args.batch_size)
    # jpeg压缩
    jpeg_quality = 100. - tf.random.uniform([]) * ramp_fn(args.jpeg_quality_ramp) * (100. - args.jpeg_quality)
    jpeg_factor = tf.cond(tf.less(jpeg_quality, 50), lambda: 5000. / jpeg_quality,
                          lambda: 200. - jpeg_quality * 2) / 100. + .0001
    # rnd_noise_ramp,default=1000
    # rnd_noise，default=.02
    # 返回一个数，标量
    rnd_noise = tf.random.uniform([]) * ramp_fn(args.rnd_noise_ramp) * args.rnd_noise
    # 对比度
    # contrast_low', type=float, default=.5
    # contrast_high', type=float, default=1.5
    # contrast_ramp', type=int, default=1000
    contrast_low = 1. - (1. - args.contrast_low) * ramp_fn(args.contrast_ramp)
    contrast_high = 1. + (args.contrast_high - 1.) * ramp_fn(args.contrast_ramp)
    contrast_params = [contrast_low, contrast_high]  # [0.5,1.5]
    # 返回一个数，标量
    rnd_sat = tf.random.uniform([]) * ramp_fn(args.rnd_sat_ramp) * args.rnd_sat
    # blur
    f = utils.random_blur_kernel(probs=[.25, .25], N_blur=7,
                                 sigrange_gauss=[1., 3.], sigrange_line=[.25, 1.], wmin_line=3)
    # 模糊卷积核
    encoded_image = tf.nn.conv2d(encoded_image, f, [1, 1, 1, 1], padding='SAME')
    # noise
    noise = tf.random_normal(shape=tf.shape(encoded_image), mean=0.0, stddev=rnd_noise, dtype=tf.float32)
    encoded_image = encoded_image + noise
    # tf.clip_by_value(A, min, max)：输入一个张量A，把A中的每一个元素的值都压缩在min和max之间。
    # 小于min的让它等于min，大于max的元素的值等于max
    encoded_image = tf.clip_by_value(encoded_image, 0, 1)
    ################################################################################################################
    # change contrast
    # # 此处是缩放因子的获取
    contrast_scale = tf.random_uniform(shape=[tf.shape(encoded_image)[0]], minval=contrast_params[0],
                                       maxval=contrast_params[1])
    contrast_scale = tf.reshape(contrast_scale, shape=[tf.shape(encoded_image)[0], 1, 1, 1])

    encoded_image = encoded_image * contrast_scale
    # bri亮度，hue色调
    encoded_image = encoded_image + rnd_brightness
    encoded_image = tf.clip_by_value(encoded_image, 0, 1)
    '''reduce_sum按照某一个维度进行加和
    expand_dims增加维度
    '''
    encoded_image_lum = tf.expand_dims(tf.reduce_sum(encoded_image * tf.constant([.3, .6, .1]), axis=3), 3)
    encoded_image = (1 - rnd_sat) * encoded_image + rnd_sat * encoded_image_lum
    encoded_image = tf.reshape(encoded_image, [-1, 400, 400, 3])
    # 前面和stegastamp一模一样
    # #rnd_bri_ramp, rnd_hue_ramp，default=1000。
    # 修改
    # rnd_bri_2 = ramp_fn(args.rnd_bri_ramp) * 0.5
    # rnd_hue_2 = ramp_fn(args.rnd_hue_ramp) * 0.4
    # 得到一个数，bri亮度，hue色调
    rnd_bri_2 = ramp_fn(args.rnd_bri_ramp * 2) * 0.5
    rnd_hue_2 = ramp_fn(args.rnd_hue_ramp * 2) * 0.4
    # light_intensity_term = tf.random.uniform([1], 0.4, 0.4+rnd_bri_2)
    # light_intensity_term = tf.random.uniform([1], 0.2, 0.2+rnd_bri_2)
    # 光线强度
    light_intensity_term = tf.random.uniform([1], 0.4, 0.4 + rnd_bri_2)
    # 光反射
    light_albedo = tf.random.uniform([3], 0.6, 0.6 + rnd_hue_2)
    encoded_image = utils.light_simulation(encoded_image, light_intensity_term, light_albedo)

    if not args.no_jpeg:
        encoded_image = utils.jpeg_compress_decompress(encoded_image, rounding=utils.round_only_at_0,
                                                       factor=jpeg_factor, downsample_c=True)
    # encoded_image = utils.motion_screen(encoded_image, batch_size)

    summaries = [tf.summary.scalar('transformer/rnd_bri', rnd_bri),
                 tf.summary.scalar('transformer/rnd_sat', rnd_sat),

                 tf.summary.scalar('transformer/rnd_bri_2', rnd_bri_2),
                 tf.summary.scalar('transformer/rnd_hue_2', rnd_hue_2),

                 tf.summary.scalar('transformer/rnd_hue', rnd_hue),
                 tf.summary.scalar('transformer/rnd_noise', rnd_noise),
                 tf.summary.scalar('transformer/contrast_low', contrast_low),
                 tf.summary.scalar('transformer/contrast_high', contrast_high),
                 tf.summary.scalar('transformer/jpeg_quality', jpeg_quality)
                 ]

    return encoded_image, summaries


def get_secret_acc(secret_true, secret_pred):
    with tf.variable_scope("acc"):
        # secret_pred = tf.round(secret_pred)
        # correct_pred = tf.count_nonzero(secret_pred - secret_true, axis=1)
        secret_pred = tf.round(tf.sigmoid(secret_pred))
        correct_pred = tf.to_int64(tf.shape(secret_pred)[1]) - tf.count_nonzero(secret_pred - secret_true, axis=1)
        str_acc = 1.0 - tf.count_nonzero(correct_pred - tf.to_int64(tf.shape(secret_pred)[1])) / tf.size(correct_pred,
                                                                                                         out_type=tf.int64)

        bit_acc = tf.reduce_sum(correct_pred) / tf.size(secret_pred, out_type=tf.int64)
        return bit_acc, str_acc


def build_model(encoder,
                decoder,
                discriminator,
                secret_input,
                image_input,
                # jnd_input,
                l2_edge_gain,
                borders,
                secret_size,
                M,
                M_RT,
                loss_scales,
                yuv_scales,
                args,
                global_step,
                batch_size):
    '''test 11-19'''
    residual = encoder((secret_input, image_input))
    encoded_image = image_input + residual
    D_output_real, _ = discriminator(image_input)
    D_output_fake, D_heatmap = discriminator(encoded_image)
    encoded_image_perspective = tf.contrib.image.transform(encoded_image, M[:, 1, :], interpolation='BILINEAR')  # 利用获取的透视矩阵进行双线性插值透视变换
    print('encoded image:', encoded_image_perspective.shape)
    transformed_image, transform_summaries = transform_net(encoded_image_perspective, args, global_step, batch_size)
    # transformed_image, transform_summaries = transform_net(encoded_image, args, global_step, batch_size)
    '''test 11-19 end'''

    decoded_secret, stn_images = decoder(transformed_image)
    '''transformation loss function: Tfx=fTx'''
    encoded_unwarped_image_residual = encoder((secret_input, image_input))  # encoder the unwarped input images
    encoded_unwarped_image = image_input + encoded_unwarped_image_residual
    encoded_image_T = tf.contrib.image.transform(encoded_unwarped_image, M_RT, interpolation='BILINEAR')  # Tfx
    mask_Tf = tf.contrib.image.transform(tf.ones_like(image_input), M_RT, interpolation='BILINEAR')
    encoded_image_T += (1 - mask_Tf) * encoded_unwarped_image
    print('encoded_image_T:', encoded_image_T)

    input_image_T = tf.contrib.image.transform(image_input, M_RT, interpolation='BILINEAR')  # Tx
    mask_fT = tf.contrib.image.transform(tf.ones_like(image_input), M_RT, interpolation='BILINEAR')
    input_image_T += (1 - mask_fT) * image_input
    fTx_residual = encoder((secret_input, input_image_T))
    fTx = input_image_T + fTx_residual
    trans_loss_op = tf.reduce_mean(tf.square(fTx - encoded_image_T))
    '''transformation loss function: end'''

    bit_acc, str_acc = get_secret_acc(secret_input, decoded_secret)

    lpips_loss_op = tf.reduce_mean(lpips_tf.lpips(image_input, encoded_image))
    secret_loss_op = tf.losses.sigmoid_cross_entropy(secret_input, decoded_secret)

    size = (int(image_input.shape[1]), int(image_input.shape[2]))
    gain = 10
    falloff_speed = 4  # Cos dropoff that reaches 0 at distance 1/x into image
    falloff_im = np.ones(size)
    for i in range(int(falloff_im.shape[0] / falloff_speed)):
        falloff_im[-i, :] *= (np.cos(4 * np.pi * i / size[0] + np.pi) + 1) / 2
        falloff_im[i, :] *= (np.cos(4 * np.pi * i / size[0] + np.pi) + 1) / 2
    for j in range(int(falloff_im.shape[1] / falloff_speed)):
        falloff_im[:, -j] *= (np.cos(4 * np.pi * j / size[0] + np.pi) + 1) / 2
        falloff_im[:, j] *= (np.cos(4 * np.pi * j / size[0] + np.pi) + 1) / 2
    falloff_im = 1 - falloff_im
    falloff_im = tf.convert_to_tensor(falloff_im, dtype=tf.float32)
    falloff_im *= l2_edge_gain

    encoded_image_yuv = tf.image.rgb_to_yuv(encoded_image)
    image_input_yuv = tf.image.rgb_to_yuv(image_input)
    im_diff = encoded_image_yuv - image_input_yuv
    im_diff += im_diff * tf.expand_dims(falloff_im, axis=[-1])
    yuv_loss_op = tf.reduce_mean(tf.square(im_diff), axis=[0, 1, 2])
    image_loss_op = tf.tensordot(yuv_loss_op, yuv_scales, axes=1)
    # jnd loss 需要自己制作jnd map数据集
    # residual_warped = tf.reshape(residual_warped, [-1,400,400,3])
    # jnd_diff = tf.abs(residual_warped) - jnd_warped*0.1
    # jnd_diff += jnd_diff * tf.expand_dims(falloff_im, axis=[-1])
    # jnd_loss_op = tf.reduce_mean(tf.square(jnd_diff))
    '''test11-19'''
    D_loss = D_output_real - D_output_fake
    G_loss = D_output_fake

    # loss_op = loss_scales[0]*image_loss_op + 5*loss_scales[1]*lpips_loss_op + 5*loss_scales[2]*secret_loss_op + 2*loss_scales[1]*jnd_loss_op
    loss_op = loss_scales[0] * image_loss_op + loss_scales[1] * lpips_loss_op + loss_scales[2] * secret_loss_op
    temporal_loss = loss_op + 200 * trans_loss_op
    if not args.no_gan:
        print('model no gan')
        loss_op += loss_scales[3] * G_loss

    summary_op = tf.summary.merge([
                                      tf.summary.scalar('bit_acc', bit_acc, family='train'),
                                      tf.summary.scalar('str_acc', str_acc, family='train'),
                                      tf.summary.scalar('loss', loss_op, family='train'),
                                      tf.summary.scalar('image_loss', image_loss_op, family='train'),
                                      tf.summary.scalar('lpip_loss', lpips_loss_op, family='train'),
                                      # tf.summary.scalar('jnd_loss', jnd_loss_op, family='train'),
                                      # tf.summary.scalar('G_loss', G_loss, family='train'),
                                      tf.summary.scalar('secret_loss', secret_loss_op, family='train'),
                                      tf.summary.scalar('trans_loss', trans_loss_op, family='train'),
                                      tf.summary.scalar('dis_loss', D_loss, family='train'),
                                      tf.summary.scalar('Y_loss', yuv_loss_op[0], family='color_loss'),
                                      tf.summary.scalar('U_loss', yuv_loss_op[1], family='color_loss'),
                                      tf.summary.scalar('V_loss', yuv_loss_op[2], family='color_loss'),
                                  ] + transform_summaries)

    image_summary_op = tf.summary.merge([
        image_to_summary(image_input, 'image_input', family='input'),
        # image_to_summary(input_warped, 'image_input_warped', family='input'),
        # image_to_summary(jnd_input, 'jnd_input', family='input'),
        # image_to_summary(jnd_warped, 'jnd_warped', family='input'),
        image_to_summary(input_image_T, 'image_input_transformation', family='input'),
        # image_to_summary(encoded_warped, 'encoded_warped', family='encoded'),
        # image_to_summary(residual_warped+.5, 'residual', family='encoded'),
        image_to_summary(encoded_image, 'encoded_image', family='encoded'),
        image_to_summary(encoded_unwarped_image, 'encoded_unwarped', family='encoded'),
        image_to_summary(fTx, 'fTx', family='encoded'),
        image_to_summary(encoded_image_T, 'Tfx', family='encoded'),
        image_to_summary(transformed_image, 'transformed_image', family='transformed'),
        image_to_summary(stn_images + .5, 'stn_images', family='transformed'),
        image_to_summary(D_heatmap, 'discriminator', family='losses'),
    ])

    return loss_op, secret_loss_op, D_loss, summary_op, image_summary_op, bit_acc, temporal_loss
    '''test11-19'''
    # return loss_op, secret_loss_op, summary_op, image_summary_op, bit_acc


# 下面的和stegastamp一样
def image_to_summary(image, name, family='train'):
    image = tf.clip_by_value(image, 0, 1)
    image = tf.cast(image * 255, dtype=tf.uint8)
    summary = tf.summary.image(name, image, max_outputs=1, family=family)
    return summary


def prepare_deployment_hiding_graph(encoder, secret_input, image_input):
    residual = encoder((secret_input, image_input))
    encoded_image = residual + image_input
    encoded_image = tf.clip_by_value(encoded_image, 0, 1)
    return encoded_image, residual


def prepare_deployment_reveal_graph(decoder, image_input):
    decoded_secret, stn_image = decoder(image_input)
    return tf.round(tf.sigmoid(decoded_secret))


if __name__ == '__main__':
    ms = MaskRCNN()
